import { useState } from 'react'
import './Header.css'
import { Icon } from '@fluentui/react'
import { IUser } from '../../Interfaces';

interface IHeaderProps{
  user:IUser;
}


function Header(props:IHeaderProps) {

  return (
    <div className='header'>
      <div className='brand'>
       <Icon iconName='Permissions' className='header-logo' />  <span>B</span>OOKING<span>P</span>ORTALEN
      </div>

      <div className='profile'>
      
      {props.user !== null && (
        <>
      <Icon iconName='Telemarketer' />
      {props.user.firstName} {props.user.lastName}
      </>
      )}


      </div>
    </div>
  )
}

export default Header
