import { useState } from 'react'
import './Menu.css'
import { Icon } from '@fluentui/react'
import { useLocation, useNavigate } from 'react-router-dom';
import { IUser } from '../../Interfaces';

interface IMenuProps{
  user:IUser | null;
  logout: () => void;
}


function Menu(props:IMenuProps) {
  let navigate = useNavigate();

  const location = useLocation();


  return (
    <div className='navigation'>



    {props.user && (
      <>
      <div className={`menu-item ${location.pathname === "/home" ? 'active' : ''}`} onClick={() => navigate("/home")}>
      <Icon className="menu-item-icon" iconName="Home" />
      <div className="menu-item-label">Hjem</div>
  </div>      
  <div className={`menu-item ${location.pathname === "/ressources" ? 'active' : ''}`} onClick={() => navigate("/ressources")}>
      <Icon className="menu-item-icon" iconName="CloneToDesktop" />
      <div className="menu-item-label">Ressourcer</div>
  </div>      
      <div className='menu-item' onClick={() => props.logout()}>
          <Icon className="menu-item-icon" iconName="SignOut" />
          <div className="menu-item-label">Logout</div>
      </div>
      </>
    )}

    </div>
  )
}

export default Menu
