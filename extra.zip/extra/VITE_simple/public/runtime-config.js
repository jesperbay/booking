window["Config"] = {
    Config: {
        AppTitle: "VagtRoste",
        APIUrlPrefix: window.location.href.indexOf("localhost") !== -1
            ? "https://localhost:7047/"
            : "https://fesbooking-api-dev.azurewebsites.net/",
        AuthType: "HYBRID",
        AuthUrl: "https://localhost:7111/authentication/me",
    },
};
