import { IIteration, ISystem } from "../Components/Interfaces"
import axios from 'axios';

const { Config } = (window as any)["Config"];

var API_URL_PREFIX = Config.APIUrlPrefix;

class SystemService {
    public GetSystems = (callback: any) => {
        var getSystemsUrl: string = API_URL_PREFIX + `system/getsystems`;
        axios.get<ISystem[]>(getSystemsUrl)
            .then((response) => {
                var systemsData = response.data;
                // console.log(systemsData);
                callback(systemsData);
            });
    }

    public GetMySystems = (callback: any) => {
        var getSystemsUrl: string = API_URL_PREFIX + `system/getsystemsbyuser`;
        axios.get<ISystem[]>(getSystemsUrl)
            .then((response) => {
                var systemsData = response.data;
                // console.log(systemsData);
                callback(systemsData);
            });
    }


    public GetSystemByOrganizationId = (organizationId: number, callback: any) => {
        var getSystemsUrl: string = API_URL_PREFIX + `system/getsystemsbyorganizationid/` + organizationId;
        axios.get<ISystem[]>(getSystemsUrl)
            .then((response) => {
                var systemsData = response.data;
                //  console.log(systemsData);
                callback(systemsData);
            });


    }

    public GetSystemBySystemId = (systemId: string, callback: any) => {
        var url: string = API_URL_PREFIX + `system/getsystembysystemid/` + systemId;
        axios.get<ISystem>(url)
            .then((response) => {
                var systemData = response.data;
                // console.log(systemsData);
                callback(systemData);
            });
    }

    public SaveSystem = (system: ISystem, callback: any) => {
        var url: string = API_URL_PREFIX + `system/savesystem`;
        axios.post(url, system)
            .then((response) => {
                var data = response.data;
                console.log(data);
                callback(true);
            });
    }

    public SaveIteration = (iteration: IIteration, callback: any) => {
        var url: string = API_URL_PREFIX + `system/saveiteration`;
        axios.post(url, iteration)
            .then((response) => {
                var data = response.data;
                console.log(data);
                callback(data);
            });
    }


    public DeleteIteration = (iteration: IIteration, callback: any) => {
        var url: string = API_URL_PREFIX + `system/deleteiteration/` + iteration.id;
        axios.post(url, '')
            .then((response) => {
                var data = response.data;
                console.log(data);
                callback(data);
            });
    }

    public AddSupplier = (systemId: number, supplierId: number, supplierRoleId: number, callback: any) => {
        var url: string = API_URL_PREFIX + `system/addsupplier/${systemId}/${supplierId}/${supplierRoleId}`;
        axios.get(url)
            .then((response) => {
                var data = response.data;
                console.log(data);
                callback(data);
            });
    }



    public RemoveSupplier = (systemId: number, supplierId: number, callback: any) => {
        var url: string = API_URL_PREFIX + `system/removesupplier/${systemId}/${supplierId}`;
        axios.get(url)
            .then((response) => {
                var data = response.data;
                console.log(data);
                callback(data);
            });
    }

}

const singleton = new SystemService();
export default singleton;