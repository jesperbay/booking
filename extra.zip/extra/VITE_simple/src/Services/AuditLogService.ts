import { IAuditLog } from "../Components/Interfaces"
import axios from 'axios';

const { Config } = (window as any)["Config"];

var API_URL_PREFIX = Config.APIUrlPrefix; // 'https://localhost:7076/';

class AuditLogService {

    public GetAuditLogs = (systemId: number, callback: any) => {
        var url: string = API_URL_PREFIX + `auditlog/getauditlogs/` + systemId;
        axios.get<IAuditLog[]>(url)
            .then((response) => {
                var data = response.data;
                // console.log(data);
                callback(data);
            });
    }
}

const singleton = new AuditLogService();
export default singleton;