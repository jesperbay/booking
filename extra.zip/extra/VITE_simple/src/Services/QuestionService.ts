import { IQuestion, IQuestionStructureVersion, IQuestionType, ISystem } from "../Components/Interfaces"
import axios from 'axios';

const { Config } = (window as any)["Config"];

var API_URL_PREFIX = Config.APIUrlPrefix;
class QuestionService {
    public GetQuestions = (callback: any) => {
        var getSystemsUrl: string = API_URL_PREFIX + `question/getquestions`;
        axios.get<IQuestion[]>(getSystemsUrl)
            .then((response) => {
                var questionsData = response.data;
                console.log(questionsData);
                callback(questionsData);
            });
    }

    public GetQuestionsByStructureVersionId = (structureVersionId: number, callback: any) => {
        var getSystemsUrl: string = API_URL_PREFIX + `question/getquestionsbystructureversionid/` + structureVersionId;
        axios.get<IQuestion[]>(getSystemsUrl)
            .then((response) => {
                var questionsData = response.data;
                console.log(questionsData);
                callback(questionsData);
            });
    }


    public GetQuestionsStructureVersions = (callback: any) => {
        var getQuestionStructureVersionsUrl: string = API_URL_PREFIX + `question/getquestionstructureversions`;
        axios.get<IQuestionStructureVersion[]>(getQuestionStructureVersionsUrl)
            .then((response) => {
                var questionStructureVersionData = response.data;
                console.log(questionStructureVersionData);
                callback(questionStructureVersionData);
            });
    }

    public GetQuestionsStructureVersionById = (structureVersionId: number, callback: any) => {
        var url: string = API_URL_PREFIX + `question/getquestionstructureversionbyid/` + structureVersionId;
        axios.get<IQuestionStructureVersion>(url)
            .then((response) => {
                var questionStructureVersionData = response.data;
                console.log(questionStructureVersionData);
                callback(questionStructureVersionData);
            });
    }

    public SaveQuestionStructureVersion = (qsv: IQuestionStructureVersion, callback: any) => {
        var url: string = API_URL_PREFIX + `question/savequestionstructureversion`;
        axios.post(url, qsv)
            .then((response) => {
                var qsvId = response.data;
                callback(qsvId);
            });
    }

    public SaveQuestion = (q: IQuestion, callback: any) => {
        var url: string = API_URL_PREFIX + `question/savequestion`;
        axios.post(url, q)
            .then((response) => {
                var qId = response.data;
                callback(qId);
            });
    }

    public DeleteQuestionStructureVersion = (qsvId: number, callback: any) => {
        var url: string = API_URL_PREFIX + `question/deletequestionstructureversion/` + qsvId;
        axios.post(url, {})
            .then((response) => {
                var success = response.data;
                callback(success);
            });
    }

    public DeleteQuestion = (questionId: number, callback: any) => {
        var url: string = API_URL_PREFIX + `question/deletequestion/` + questionId;
        axios.post(url, {})
            .then((response) => {
                var success = response.data;
                callback(success);
            });
    }


    public GetQuestionTypes = (callback: any) => {
        var url: string = API_URL_PREFIX + `question/getquestiontypes`;
        axios.get<IQuestionType[]>(url)
            .then((response) => {
                var questionTypesData = response.data;
                console.log(questionTypesData);
                callback(questionTypesData);
            });
    }
}

const singleton = new QuestionService();
export default singleton;