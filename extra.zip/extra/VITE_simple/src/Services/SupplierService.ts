import { IAnswer, IQuestion, ISupplier, ISupplierRole, ISystem } from "../Components/Interfaces"
import axios from 'axios';

const { Config } = (window as any)["Config"];

var API_URL_PREFIX = Config.APIUrlPrefix;

class SupplierService {

    public GetSuppliers = (callback: any) => {
        var url: string = API_URL_PREFIX + `supplier/getsuppliers`;
        axios.get<ISupplier[]>(url)
            .then((response) => {
                var suppliersData = response.data;
                console.log(suppliersData);
                callback(suppliersData);
            });
    }

    public SaveSupplier = (s: ISupplier, callback: any) => {
        var url: string = API_URL_PREFIX + `supplier/savesupplier`;
        axios.post(url, s)
            .then((response) => {
                var supplierId = response.data;
                callback(supplierId);
            });
    }

    public DeleteSupplier = (supplierId: number, callback: any) => {
        var url: string = API_URL_PREFIX + `supplier/deletesupplier/` + supplierId;
        axios.post(url, {})
            .then((response) => {
                var success = response.data;
                callback(success);
            });
    }

    public GetSupplierRoles = (callback: any) => {
        var url: string = API_URL_PREFIX + `supplier/getsupplierroles`;
        axios.get<ISupplierRole[]>(url)
            .then((response) => {
                var supplierRolesData = response.data;
                console.log(supplierRolesData);
                callback(supplierRolesData);
            });
    }

}

const singleton = new SupplierService();
export default singleton;