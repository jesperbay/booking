import { IAnswer, IQuestion, ISystem } from "../Components/Interfaces"
import axios from 'axios';

const { Config } = (window as any)["Config"];

var API_URL_PREFIX = Config.APIUrlPrefix; // 'https://localhost:7076/';

class AnswerService {

    public GetAnswersByIterationId = (iterationId: number, callback: any) => {
        var getAnswersUrl: string = API_URL_PREFIX + `answer/getanswersbyiterationid/` + iterationId;
        axios.get<IQuestion[]>(getAnswersUrl)
            .then((response) => {
                var answersData = response.data;
                // console.log(answersData);
                callback(answersData);
            });
    }

    public SaveAnswer = (answer: IAnswer, callback: any) => {
        var url: string = API_URL_PREFIX + `answer/saveanswer`;
        axios.post(url, answer)
            .then((response) => {
                var answerId = response.data;
                callback(answerId);
            });
    }

}

const singleton = new AnswerService();
export default singleton;