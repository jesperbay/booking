import { IAnswer, IOrganization, ISystem } from "../Components/Interfaces"
import axios from 'axios';

const { Config } = (window as any)["Config"];

var API_URL_PREFIX = Config.APIUrlPrefix;

class OrganizationService {
    public GetOrganizations = (callback: any) => {
        var getOrganizationsUrl: string = API_URL_PREFIX + `organization/getorganizations`;
        axios.get<IOrganization[]>(getOrganizationsUrl)
            .then((response) => {
                var organizationsData = response.data;
                // console.log(organizationsData);
                callback(organizationsData);
            });
    }
}
const singleton = new OrganizationService();
export default singleton;