import { IAnswer, IQuestion, IRole, ISystem } from "../Components/Interfaces";
import axios from "axios";

const { Config } = (window as any)["Config"];

var API_URL_PREFIX = Config.APIUrlPrefix;

class UserService {
  public GetUsers = (callback: any) => {
    var getUsersUrl: string = API_URL_PREFIX + `user/getusers`;
    axios.get<IQuestion[]>(getUsersUrl).then((response) => {
      var usersData = response.data;
      console.log(usersData);
      callback(usersData);
    });
  };

  public ValidateUsername = (username: string, ensureUser: boolean = false, callback: any) => {
    var url: string = API_URL_PREFIX + `user/validateusername/` + username + `/` + ensureUser;
    axios.get(url).then((response: any) => {
      var userValid = response.data;
      console.log(userValid);
      callback(userValid);
    });
  };

  public SaveUser = (user: any, callback: any) => {
    var url: string = API_URL_PREFIX + `user/saveuser`;
    axios.post(url, user).then((response: any) => {
      var userSaved = response.data;
      console.log(userSaved);
      callback(userSaved);
    });
  };

  public SaveUserRoles = (userId: number, roleIds: number[], callback: any) => {
    var url: string = API_URL_PREFIX + `user/saveuserroles/` + userId;
    axios.post(url, roleIds).then((response: any) => {
      var userSaved = response.data;
      console.log(userSaved);
      callback(userSaved);
    });
  };

  public AddUserToSystem = (userId: number, systemId: number, permissionId: number, callback: any) => {
    var url: string = API_URL_PREFIX + `user/addusertosystem/` + userId + `/` + systemId + `/` + permissionId;
    axios.post(url).then((response: any) => {
      var userAdded = response.data;
      console.log(userAdded);
      callback(userAdded);
    });
  };

  public RemoveUserFromSystem = (userId: number, systemId: number, permissionId: number, callback: any) => {
    var url: string = API_URL_PREFIX + `user/removeuserfromsystem/` + userId + `/` + systemId + `/` + permissionId;
    axios.post(url).then((response: any) => {
      var userRemoved = response.data;
      console.log(userRemoved);
      callback(userRemoved);
    });
  };

  public GetRoles = (callback: any) => {
    var url: string = API_URL_PREFIX + `user/getroles`;
    axios.get<IRole[]>(url).then((response) => {
      var rolesData = response.data;
      console.log(rolesData);
      callback(rolesData);
    });
  };

}

const singleton = new UserService();
export default singleton;
