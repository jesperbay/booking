import { IGroup } from "@fluentui/react";

export interface IQuestionType {
  id: number;
  name: string;
}

export interface IQuestionGroup {
  id: number;
  name: string;
  order: number;
}

export interface IQuestionStructureVersion {
  id: number;
  version: string;
  enabled: boolean;
  scope: string;
  questionStructures: IQuestionStructure[];
  iterations: IIteration[];
  created: Date;
  modified: Date;
  type: string;
}

export interface IQuestionStructure {
  id: number;
  question: IQuestion | null;
  questionId: number;
  questionOrder: number;
  group: IQuestionGroup;
  groupId: number;
  groupOrder: number;
  enabled: boolean;
  questionStructureVersionId: number;
  section: string | null;
  sectionOrder: number | null;
}

export interface IQuestionOption {
  id: number;
  option: string;
  order: number;
}

export interface IQuestion {
  id: number;
  questionId: string;
  question1: string;
  description: string;
  typeId: number;
  type: IQuestionType | null;
  group: IQuestionGroup | null;
  order: number;
  enabled: boolean;
  classified: boolean;
  questionOptions: IQuestionOption[];
  questionStructures: IQuestionStructure[];
  structureversion: number;
  tags: string;
  relatedQuestionIds: string;
}

export interface IAnswer {
  id: number;
  answer1: string;
  notes: string;
  questionId: number;
  answerNotes: IAnswerNote[];
  iterationId: number;
  created: Date | null;
  createdById: number;
  createdBy: IUser | null;
  modified: Date | null;
  modifiedById: number;
  modifiedBy: IUser | null;
}

export interface IAnswerNote {
  id: number;
  answerId: number;
  note: string;
  created: Date;
  createdById: number;
  createdBy: IUser;
  modified: Date;
  modifiedById: number;
  modifiedBy: IUser;
}

export interface ISystem {
  id: number;
  systemId?: string;
  name: string;
  description: string;
  status: string;
  created: Date;
  createdById: number;
  createdBy: IUser | null;
  modified: Date;
  modifiedById: number;
  modifiedBy: IUser | null;
  ownerId: number;
  owner: IUser | null;
  organizationId: number;
  organization: IOrganization | null;
  iterations: IIteration[];
  systemSuppliers: ISystemSupplier[];
  systemUsers: ISystemUser[];
}

export interface IIteration {
  id: number;
  guid: string;
  version: number;
  status: string;
  assignedToId: number;
  assignedTo: IUser | null;
  started: Date;
  finished: Date | null;
  latestUpdate: Date;
  approved: Date | null;
  approvedById: number | null;
  approvedBy: IUser | null;
  systemId: number;
  questionStructureVersion: IQuestionStructureVersion | null;
  questionStructureVersionId: number;
  answers: IAnswer[];
  entityId: number;
  entityName: string | null;
}

export interface IOrganization {
  id: number;
  name: string;
}

export interface IUser {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  stabsnr: string;
  organizationId: number;
  organization: IOrganization | null;
  tags: string;
  userRoles: IUserRole[];
  systemUsers: ISystemUser[];
  lastLogin: Date | null;
}

export interface IUserRole {
  id: number;
  userId: number;
  roleId: number;
}

export interface IRole {
  id: number;
  name: string;
  permissionRoles: IPermissionRole[];
}

export interface IPermissionRole {
  id: number;
  permission: IPermission;
}

export interface IPermission {
  id: number;
  name: string;
}

export interface ISystemUser {
  id: number;
  permission: IPermission;
  system: ISystem;
  user: IUser;
}

export interface ISupplier {
  id: number;
  name: string;
  systemSuppliers: ISystemSupplier[];
}

export interface ISystemSupplier {
  id: number;
  systemId: number;
  supplierId: number;
  supplier: ISupplier;
  supplierRole: ISupplierRole;
  supplierRoleId: number;
}

export interface ISupplierRole {
  id: number;
  role: string;
}


export interface IAuditLog {
  id: number;
  log: string;
  entityType: string;
  entityId: number;
  timestamp: Date;
  userId: number;
  username: string;
  text: string;
  logType: string;
  ip: string;
  browserAgent: string;
  systemId: number;
  iterationId: number;
}

