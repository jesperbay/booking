import React, { ReactElement } from 'react';
import useAuth from './AuthProvider';
import { IPermission, ISystem, ISystemUser, IUser } from '../Interfaces';

interface IPermissionWrapperProps {
    permissionsRequired: string[];
    createdById?: number;
    contactPersonId?: number;
    responsiblePersonId?: number;
    children: ReactElement<any, any | null>;
    showNotFound?: boolean;
}


export const PermissionWrapper: React.FC<IPermissionWrapperProps> = (props: IPermissionWrapperProps) => {
    const { user } = useAuth();

    if (props.createdById && props.createdById === user?.id) {
        return props.children;
    }

    if (props.responsiblePersonId && props.responsiblePersonId === user?.id) {
        return props.children;
    }

    if (props.contactPersonId && props.contactPersonId === user?.id) {
        return props.children;
    }

    if (userHasPermissions(props.permissionsRequired, user)) {
        return props.children;
    }

    return props.showNotFound ? (<span>Du har desværre ikke adgang til denne ressource.</span>) : null;
}

export const userHasPermissions = (permissionsRequired: string[], user: IUser | undefined): boolean => {
    if (!(user && user.userRoles)) return false

    return user.userRoles.some(({ role }) => role.permissionRoles.some(({ permission }) => permissionsRequired.includes(permission.name)))
}

export const userHasRole = (roleName: string[], user: IUser | undefined): boolean => {
    if (user?.userRoles?.some(role => role.role.name === "Administrator"))
        return true
    if (user && user.userRoles) {
        if (!roleName.every(name => user.userRoles!.some(rn => rn.role.name === name)))
            return false
    }
    return true;
}

export const userHasSystemPermissions = (permissionsRequired: string[], user: IUser | undefined, system: ISystem): boolean => {
    if (!(user && user.userRoles)) return false

    var hasPermission = false;

    user.systemUsers.forEach((systemUser: ISystemUser) => {
        if (systemUser.system.id === system.id && !hasPermission) {
            hasPermission = permissionsRequired.includes(systemUser.permission.name);
            if (hasPermission) {
                return;
            }
        }
    });
    return hasPermission;

}
