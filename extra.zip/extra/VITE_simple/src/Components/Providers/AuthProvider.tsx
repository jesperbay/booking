import axios from "axios";
import React, {
    createContext,
    ReactNode,
    useContext,
    useEffect,
    useMemo,
    useState,
} from "react";
// import { useLocation } from "react-router-dom";
// import { IEmployee } from "../../../interfaces/interfaces";
// import { ISetting } from "../../Pages/Settings/Settings";
import { IUser } from '../Interfaces';
import { useLocation, useNavigate } from "react-router-dom";
import AuthService from "../../Services/AuthService";

const { Config } = (window as any)["Config"];

export interface AuthContextType extends AdditionalContextProps {
    user?: IUser;
    loading: boolean;
    error?: any;
}

export interface AdditionalContextProps {
    APIUrlPrefix: string;
    assetUrlPrefix: string;
    redirect_uri: string;
    login: (email: string, password: string, code: string, callback: any) => void;
    logout: () => void;
    handleWindowsLogin: (callback: any) => void;
    //settings: ISetting[];
}

const AuthContext = createContext<AuthContextType>(
    {} as AuthContextType
);

export const AuthProvider = ({ children }: { children: ReactNode; }): JSX.Element => {
    const [user, setUser] = useState<IUser>();
    // const [settings, setSettings] = useState<ISetting[]>([]);
    // const [globalSettings, setGlobalSettings] = useState({} as any);
    const [error] = useState<any>();
    const [loading, setLoading] = useState<boolean>(false);
    const [loadingInitial, setLoadingInitial] = useState<boolean>(true);

    const [features, setFeatures] = useState<{ [key: string]: boolean }>({});
    const [apiUrlPrefix] = useState<string>(Config.APIUrlPrefix);
    const [oAuthRedirectUri, setOAuthRedirectUri] = useState<string>(Config.OAuthRedirectUri);
    const [openIDConnectUrlPrefix, setOpenIDConnectUrlPrefix] = useState<string>(Config.OpenIDConnectUrlPrefix);
    const [assetUrlPrefix] = useState<string>(Config.AssetsUrlPrefix);
    const [AuthType] = useState<string>(Config.AuthType);
    const [AuthUrl] = useState<string>(Config.AuthUrl);

    const redirect_uri = oAuthRedirectUri; // window.location.href.indexOf("localhost") !== -1 ? "http://localhost:3000" : window.location.href.indexOf("test.mitfes.dk")!== -1 ? "https://test.mitfes.dk" : "https://mitfes.dk";
    const client_id = window.location.href.indexOf("localhost") !== -1 ? "festest" : "mitfes.dk";

    let navigate = useNavigate();

    const urlParams = new URLSearchParams(location.search);

    useEffect(() => {
        console.log('AuthProvider running');



        if (!user) {
            console.log('AuthType: ' + AuthType);

            var lexiToken: string | null = localStorage.getItem('lexi-token');
            if (!lexiToken) {
                if (AuthType === 'FORM') {
                    console.log('No token - Redirect to login');
                    navigate("/login");
                }

                if (AuthType === 'HYBRID') {
                    console.log('No token - Redirect to login');
                    navigate("/login");
                }

                if (AuthType === 'WINDOWS') {
                    handleWindowsLogin(() => {
                        console.log('logged in!');
                    })
                }
            }
            else {
                console.log('Found token - Validate');
                AuthService.ValidateToken(lexiToken, (user: IUser | null) => {
                    if (user) {
                        console.log('Token valid', user);
                        setUser(user);
                    } else {
                        console.log('Token invalid or expired - Redirect to login');
                        localStorage.removeItem('lexi-token');
                        navigate("/login");

                    }
                });
            }
        }
    }, []);

    const logout = () => {
        localStorage.removeItem('lexi-token');
        setUser(undefined);
        location.href = location.protocol + '//' + location.hostname + ':' + location.port;
    }

    const handleWindowsLogin = (callback: any) => {
        AuthService.HandleSSOLogin((user: any | null) => {
            console.log(user);

            AuthService.HandleValidateSSOLogin(user, (lexiToken: any | null) => {
                console.log(lexiToken);
                if (lexiToken.length > 0) {
                    localStorage.setItem('lexi-token', lexiToken);
                    setTimeout(() => {
                        location.href = location.protocol + '//' + location.hostname + ':' + location.port;
                        // AuthService.ValidateToken(lexiToken, (user: IUser | null) => {
                        //     if (user) {
                        //         console.log('Token valid', user);
                        //         setUser(user);
                        //         callback(true);
                        //     } else {
                        //         console.log('Token invalid or expired - Redirect to login');
                        //         callback(false);
                        //         navigate("/login");
                        //     }
                        // });
                    }, 1000);
                }
            });
        });

    }

    const login = (maNo: string, password: string, code: string, callback: any) => {
        console.log(`login called! (${maNo})`);
        AuthService.HandleLogin(maNo, (token: string) => {
            var token: string = token;
            if (token.length > 0) {
                localStorage.setItem('lexi-token', token);
                location.href = location.protocol + '//' + location.hostname + ':' + location.port + '/';
                callback(true);
            }
            else {
                callback(false);
            }
        });
    }

    const memoedValue = useMemo(
        () => ({
            user,
            loading,
            error,
            APIUrlPrefix: apiUrlPrefix,
            assetUrlPrefix,
            login,
            logout,
            handleWindowsLogin,
            redirect_uri
        }),
        [user, loading, error, features]
    );

    return (
        <AuthContext.Provider value={memoedValue}>
            {children}
        </AuthContext.Provider>
    );
}

export default function useAuth() {
    return useContext(AuthContext);
}
