//#region "Imports"
import { useEffect, useState } from 'react'
import { DetailsList, DetailsListLayoutMode, IColumn, SelectionMode, Panel, PanelType, TextField, Icon, Checkbox, DefaultButton } from '@fluentui/react';
import { format } from 'date-fns';
import './Users.css'
import { IRole, ISystemUser, IUser, IUserRole } from '../Interfaces';
import { userHasPermissions } from '../Providers/PermissionWrapper';
import UserService from '../../Services/UserService';
import { Bounce, ToastContainer, toast } from 'react-toastify';
//#endregion "Imports"

function Users(props: any) {
    //#region "States"
    const [users, setUsers] = useState<IUser[]>([])
    const [roles, setRoles] = useState<IRole[]>([])
    const [selectedRoleIds, setSelectedRoleIds] = useState<number[]>([])
    const [isUserPanelOpen, setIsUserPanelOpen] = useState<boolean>(false);
    const [editingUser, setEditingUser] = useState<IUser | null>(null)
    const [usersColumns, setUsersColumns] = useState<IColumn[]>([]);
    //#endregion "States"

    //#region "useEffects"
    useEffect(() => {
        console.log('Initial useEffect');

        if (users.length === 0) {
            loadUsers();
        }

        if (roles.length === 0) {
            loadRoles()
        }

        if (usersColumns.length === 0) {
            loadColumns()
        }
    }, [])
    //#endregion "useEffects"

    //#region "Data load"
    const loadUsers = () => {
        UserService.GetUsers((data: IUser[]) => {
            var us: IUser[] = data;

            console.log(us, 'users');
            setUsers(us);

        });
    }

    const loadRoles = () => {
        UserService.GetRoles((data: IRole[]) => {
            var rs: IRole[] = data;

            //console.log(rs, 'users');
            setRoles(rs);

        });
    }
    //#endregion "Data load"

    //#region "Event handlers"
    const handleEditUser = (user: IUser) => {

        setEditingUser(user);

        var userRoleIds: number[] = user.userRoles.map((ur: IUserRole) => { return ur.roleId });

        console.log(userRoleIds);
        setSelectedRoleIds(userRoleIds);

        setIsUserPanelOpen(true);
    }

    const syncSelectedRoles = (role: IRole) => {

        var foundRole = selectedRoleIds.filter((r: number) => r === role.id);

        if (foundRole.length === 1) {
            //     // remove it
            var index = selectedRoleIds.indexOf(role.id);
            selectedRoleIds.splice(index, 1);
        }
        else {
            selectedRoleIds.push(role.id);
        }
        setSelectedRoleIds([...selectedRoleIds]);
    }

    const saveUser = () => {
        UserService.SaveUserRoles(editingUser!.id, selectedRoleIds, (data: IUser) => {
            var user: IUser = data;
            console.log(user, 'user');
            loadUsers();

            setIsUserPanelOpen(false);
            setEditingUser(null);

            toast.info(`${editingUser?.firstName} ${editingUser?.lastName}'s rettigheder opdateret`, {
                position: "top-center",
                autoClose: 3000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: 0,
                theme: "light",
                transition: Bounce,
            });
        });

    }
    //#endregion "Event handlers"

    //#region "UI helpers (Detailsview columns etc)"
    const getSystemPermissions = (user: IUser) => {

        var systems: string[] = [];
        var permissions: string = '';
        {
            user.systemUsers.map((systemUser: ISystemUser) => {
                var strSystemPermissions: string = '';

                if (systems.filter((system: string) => system === systemUser.system.name).length === 0) {
                    systems.push(systemUser.system.name);

                    var systemPermissions: ISystemUser[] = user.systemUsers.filter((su: ISystemUser) => su.system.name === systemUser.system.name);
                    systemPermissions.forEach((su: ISystemUser) => {
                        strSystemPermissions += su.permission.name + ', ';
                    });
                    strSystemPermissions = strSystemPermissions.substring(0, strSystemPermissions.length - 2);
                    permissions += systemUser.system.name + ' (' + strSystemPermissions + ')' + ', ';
                }
            })
            permissions = permissions.substring(0, permissions.length - 2);
        }
        return permissions;
    }

    const loadColumns = () => {
        const columns: IColumn[] = [
            {
                key: 'column0',
                name: '',
                minWidth: 60,
                maxWidth: 60,
                isResizable: true,
                data: 'string',
                onRender: (user: IUser) => {
                    return (
                        <>
                            {userHasPermissions(["All.Update", "Users.Update"], props.currentUser) && (
                                <span><Icon style={{ cursor: 'pointer', fontSize: '16px' }} iconName="Edit" onClick={() => handleEditUser(user)} /></span>
                            )}
                        </>
                    );
                },
            },
            {
                key: 'column1',
                name: 'Navn',
                fieldName: 'firstName',
                minWidth: 150,
                maxWidth: 150,
                isResizable: true,
                data: 'string',
                onRender: (user: IUser) => {
                    return <span>{user.firstName} {user.lastName}</span>;
                },
            },
            {
                key: 'column2',
                name: 'Myndighed',
                minWidth: 70,
                maxWidth: 90,
                isResizable: true,
                data: 'string',
                onRender: (user: IUser) => {
                    return <span>{user.organization!.name}</span>;
                },
            },
            {
                key: 'column3',
                name: 'Stabsnr',
                fieldName: 'stabsnr',
                minWidth: 140,
                maxWidth: 140,
                isRowHeader: true,
                isResizable: true,
                onRender: (user: IUser) => {
                    return <span>{user.stabsnr}</span>;
                },
            },
            {
                key: 'column4',
                name: 'Roller',
                minWidth: 150,
                maxWidth: 150,
                isRowHeader: true,
                isResizable: true,
                onRender: (user: IUser) => {
                    return <span>
                        {user.userRoles.map((userRole: any) => {
                            return (<div key={userRole.id}>{userRole.role !== undefined && userRole.role.name}</div>)
                        })}
                    </span>;
                },
            },
            {
                key: 'column5',
                name: 'Sidste login',
                minWidth: 120,
                maxWidth: 120,
                isRowHeader: true,
                isResizable: true,
                onRender: (user: IUser) => {
                    return <span>
                        {user.lastLogin !== null && format(user.lastLogin, 'dd.MM.yyyy HH:mm')}
                    </span>;
                },
            },
            {
                key: 'column6',
                name: 'Systemer',
                minWidth: 210,
                maxWidth: 350,
                isRowHeader: true,
                isResizable: true,
                onRender: (user: IUser) => {
                    return <span>
                        {getSystemPermissions(user)}
                    </span>;
                },
            }
        ];

        setUsersColumns(columns);
    }

    const handleColumnSorting = (ev?: React.MouseEvent<HTMLElement>, column?: IColumn): void => {
        if (column?.fieldName !== null && column?.fieldName !== undefined) {
            const newColumns: IColumn[] = usersColumns.slice();
            const currColumn: IColumn = newColumns.filter(currCol => column?.key === currCol.key)[0];
            newColumns.forEach((newCol: IColumn) => {
                if (newCol === currColumn) {
                    currColumn.isSortedDescending = !currColumn.isSortedDescending;
                    currColumn.isSorted = true;
                    // this.setState({
                    //   announcedMessage: `${currColumn.name} is sorted ${
                    //     currColumn.isSortedDescending ? 'descending' : 'ascending'
                    //   }`,
                    // });
                } else {
                    newCol.isSorted = false;
                    newCol.isSortedDescending = true;
                }
            });
            const sortedUsers = f_sort(users, currColumn.fieldName!, currColumn.isSortedDescending); //_copyAndSort(systems, currColumn.fieldName!, currColumn.isSortedDescending);

            setUsersColumns(newColumns);
            setUsers(sortedUsers);
        }

    };

    function f_sort(dataArg: any[], colName: string, isSortedDescending?: boolean) {

        dataArg.sort(function (res01, res02) {
            var arg01 = res01[colName] !== null ? res01[colName].toString().toLowerCase() : '';
            var arg02 = res02[colName] != null ? res02[colName].toString().toLowerCase() : '';
            if (arg01 < arg02) { return isSortedDescending ? 1 : -1; }
            if (arg01 > arg02) { return !isSortedDescending ? 1 : -1 }
            return 0;
        });
        return dataArg;
    }
    //#endregion

    //#region "Additional Renders"
    const renderEditUserPanel = () => {

        return (
            <Panel
                headerText={"Rediger bruger"}
                isOpen={isUserPanelOpen}
                onDismiss={() => {
                    //setEditingQuestion(null);

                    // setQuestion('');
                    // setQuestionId('');
                    // setDescription('');
                    // setTags('');
                    // setRelatedQuestionIds('');
                    setIsUserPanelOpen(false);
                }
                }
                // You MUST provide this prop! Otherwise screen readers will just say "button" with no label.
                closeButtonAriaLabel="Close"
                type={PanelType.medium}
            >
                <div className='question-panel-wrapper'>
                    <TextField
                        className='question-panel-item'
                        value={editingUser?.firstName}
                        readOnly
                        label='Fornavn'></TextField>
                    <TextField
                        className='question-panel-item'
                        value={editingUser?.lastName}
                        readOnly
                        label='Efternavn'></TextField>

                    <div className='module-header-spacer'>Roller</div>

                    {roles.map((role: IRole) => (
                        <>
                            <Checkbox
                                checked={selectedRoleIds.filter((sr: number) => sr === role.id).length > 0}
                                className='question-panel-item-checkbox'
                                label={role.name}
                                onChange={(_event: any, _value: any) => syncSelectedRoles(role)}
                            ></Checkbox>
                        </>
                    ))}







                    <DefaultButton
                        className='question-panel-savebutton'
                        onClick={() => saveUser()}
                    >

                        Gem
                    </DefaultButton>



                </div>
            </Panel >
        )

    }
    //#endregion

    return (
        <>
            {userHasPermissions(["All.Read", "Users.Read"], props.currentUser) && (
                <div>
                    <div className='module-header-spacer'>Brugere</div>
                    {users.length > 0 && (
                        <div>

                            <DetailsList
                                items={users}
                                columns={usersColumns}
                                setKey="single"
                                layoutMode={DetailsListLayoutMode.justified}
                                isHeaderVisible={true}
                                selectionPreservedOnEmptyClick={true}
                                selectionMode={SelectionMode.none}
                                onColumnHeaderClick={(ev?: React.MouseEvent<HTMLElement>, column?: IColumn) => handleColumnSorting(ev, column)}
                            ></DetailsList>

                        </div>
                    )}
                </div>
            )}
            {renderEditUserPanel()}
            <ToastContainer />
        </>
    )
}
export default Users
