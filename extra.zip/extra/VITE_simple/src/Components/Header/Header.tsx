
import { Icon } from '@fluentui/react';
import './Header.css'
import { IUser } from '../Interfaces';
import { useNavigate } from 'react-router-dom';


const { Config } = (window as any)["Config"];

// export interface IHeaderProps {
//     user: IUser | undefined;
// }

function Header(props: any) {

    let navigate = useNavigate();

    return (
        <div className='header-wrapper'>
            <div className='brand-wrapper'>
                <div className='header-logo'><Icon className='user-icon' iconName="CalendarSettings" onClick={() => navigate('/profile')} /></div>
                <div className='header-title'>{Config.AppTitle}</div>
            </div>
            {props.user !== null && props.user !== undefined && (
                <div className='user-wrapper'>
                    <Icon className='user-icon' iconName="Contact" onClick={() => navigate('/profile')} />
                    <div className='user'

                        onDoubleClick={() => props.logout()}>
                        {props.user.firstName} {props.user.lastName}
                    </div>
                </div>

            )}
        </div>
    )


}

export default Header
