import { useEffect, useState, useRef } from 'react'
import * as React from 'react';
import { IQuestion, IQuestionOption, ISystem } from '../Interfaces';
import { Selection, Checkbox, DetailsList, DetailsListLayoutMode, Dropdown, IColumn, ICommandBarItemProps, IDropdownOption, IDropdownStyles, SelectionMode, CommandBar, Panel, PanelType, TextField, DefaultButton, Stack, Pivot, PivotItem, Icon, Dialog, DialogFooter, PrimaryButton, DialogType } from '@fluentui/react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import './Questions.css'
import { IQuestionStructureVersion, IQuestionType } from '../Interfaces';
import QuestionService from '../../Services/QuestionService';
import { userHasPermissions } from '../Providers/PermissionWrapper';
import { DialogContent } from '@fluentui/react-components';
import { Bounce, ToastContainer, toast } from 'react-toastify';
import { Editor } from '@tinymce/tinymce-react';
import 'react-toastify/dist/ReactToastify.css';

const dropdownStyles: Partial<IDropdownStyles> = {
    dropdown: { width: '100%' },
};

const dialogContentProps = {
    type: DialogType.normal,
    title: 'Bekræft sletning',
    closeButtonAriaLabel: 'Close',
    subText: '',
};

const stackTokens = { childrenGap: 10 };

const dialogStyles = { main: { maxWidth: 450 } };
const iconStyles = { marginRight: '8px' };

var gInitiating = false;

function Questions(props: any) {
    const [questions, setQuestions] = useState<IQuestion[]>([])
    const [filteredQuestions, setFilteredQuestions] = useState<IQuestion[]>([])
    const [questionsStructureVersions, setQuestionsStructureVersions] = useState<IQuestionStructureVersion[]>([])
    //   const [selectedQuestionsStructureVersion, setSelectedQuestionsStructureVersion] = React.useState<IDropdownOption>();
    //const [questionsStructureVersionOptions, setQuestionsStructureVersionOptions] = React.useState<IDropdownOption[]>([])
    //const [editSystemOpen, setEditSystemOpen] = React.useState<boolean>(false);
    const [, setSelectedItems] = useState<ISystem[]>([]);
    const [isQuestionPanelOpen, setIsQuestionPanelOpen] = useState<boolean>(false);
    const [questionTypeOptions, setQuestionTypeOptions] = useState<IDropdownOption[]>([])
    const [questionTypes, setQuestionTypes] = useState<IQuestionType[]>([])
    const [selectedQuestionType, setSelectedQuestionType] = useState<string>('')
    const [selectedQuestionOptions, setSelectedQuestionOptions] = useState<string>('')
    const [initialQuestionOptions, setInitialQuestionOptions] = useState<IQuestionOption[]>([])
    const [editingQuestion, setEditingQuestion] = useState<IQuestion | null>(null)
    const [selectedQuestion, setSelectedQuestion] = useState<IQuestion | null>(null)
    const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState<boolean>(false);
    const [question, setQuestion] = useState<string>('')
    const [questionId, setQuestionId] = useState<string>('')
    const [description, setDescription] = useState<string>('')
    const [tags, setTags] = useState<string>('')
    const [relatedQuestionIds, setRelatedQuestionIds] = useState<string>('')
    const [classified, setClassified] = useState<boolean>(false)
    const [questionIdCollision, setQuestionIdCollision] = useState<boolean>(false);


    const [commandBarQuestionItems, setCommandBarQuestionItems] = useState<ICommandBarItemProps[]>([])
    const [commandBarQSVItems, setCommandBarQSVItems] = useState<ICommandBarItemProps[]>([])
    const [mceValue, setMCEValue] = useState<string>('')

    const [questionsColumns, setQuestionsColumns] = useState<IColumn[]>([]);
    const [qsvColumns, setQSVColumns] = useState<IColumn[]>([]);

    /* TinyMCE */
    const editorRef = useRef('');

    const [_selection] = useState(new Selection({
        onSelectionChanged: () => {
            setSelectedItems((_selection.getSelection() as ISystem[]))
        }
    }));

    let navigate = useNavigate();

    useEffect(() => {
        console.log('Initial useEffect');

        if (!gInitiating) {
            gInitiating = true;

            if (questionsStructureVersions.length === 0) {
                loadQuestionsStructureVersions();
            }

            if (questions.length === 0) {
                loadQuestions();
            }

            if (questionTypes.length === 0) {
                loadQuestionTypes();
            }

            if (questionsColumns.length === 0) {
                loadQuestionColumns();
            }
            if (qsvColumns.length === 0) {
                loadQSVColumns();
            }


            setTimeout(() => {
                gInitiating = false;

                if (commandBarQuestionItems.length === 0) {
                    loadCommandBarQuestionItems();
                }

                if (commandBarQSVItems.length === 0) {
                    loadCommandBarQSVItems();
                }
            }, 1000);
        }

    }, [])

    const loadQuestions = () => {
        QuestionService.GetQuestions((data: IQuestion[]) => {
            var qs: IQuestion[] | null = data;

            setQuestions(qs);
            setFilteredQuestions(qs);
        });
    }

    const loadQuestionTypes = () => {
        QuestionService.GetQuestionTypes((data: IQuestionType[]) => {
            var qts: IQuestionType[] | null = data;
            setQuestionTypes(qts);

            loadQuestionTypeOptions(qts);
        });
    }

    const loadQuestionTypeOptions = (qts: IQuestionType[], selectedQuestionTypeId: number = 0) => {
        var ddOptions: IDropdownOption[] = [];
        qts.map((type: IQuestionType) => {
            var iconName = type.id === 1 ? 'Remove' :
                type.id === 2 ? 'GlobalNavButton' :
                    type.id === 3 ? 'Sort' :
                        type.id === 4 ? 'CheckboxComposite' :
                            type.id === 5 ? 'NumberSymbol' :
                                type.id === 8 ? 'Calendar' :
                                    type.id === 6 ? 'UserFollowed' : ''

            if (selectedQuestionTypeId > 0) {
                if (type.id === selectedQuestionTypeId) {
                    ddOptions.push({ key: type.id.toString(), text: type.name, data: { icon: iconName }, selected: true })
                    setSelectedQuestionType(type.id.toString());


                } else {

                    ddOptions.push({ key: type.id.toString(), text: type.name, data: { icon: iconName } })
                }
            }
            else {

                ddOptions.push({ key: type.id.toString(), text: type.name, data: { icon: iconName } })
            }
        });
        setQuestionTypeOptions(ddOptions);
    }

    const getQuestionTypeOptions = (qts: IQuestionType[], selectedQuestionTypeId: number = 0) => {
        var ddOptions: IDropdownOption[] = [];
        qts.map((type: IQuestionType) => {
            var iconName = type.id === 1 ? 'Remove' :
                type.id === 2 ? 'GlobalNavButton' :
                    type.id === 3 ? 'Sort' :
                        type.id === 4 ? 'CheckboxComposite' :
                            type.id === 5 ? 'NumberSymbol' :
                                type.id === 8 ? 'Calendar' :
                                    type.id === 6 ? 'UserFollowed' : ''

            if (selectedQuestionTypeId > 0) {
                if (type.id === selectedQuestionTypeId) {
                    ddOptions.push({ key: type.id.toString(), text: type.name, data: { icon: iconName }, selected: true })
                    //setSelectedQuestionType(type.id.toString());


                } else {

                    ddOptions.push({ key: type.id.toString(), text: type.name, data: { icon: iconName } })
                }
            }
            else {

                ddOptions.push({ key: type.id.toString(), text: type.name, data: { icon: iconName } })
            }
        });
        return ddOptions;
    }

    // const updateValue = (value: any) => {
    //     props.updateValue(value, props.question.id);
    // }

    // const loadSystems = () => {
    //     SystemService.GetSystems((data: ISystem[]) => {
    //         var ss: ISystem[] = data;
    //         console.log(ss, 'ss');
    //         setSystems(ss);

    //     });
    // }

    const loadQuestionsStructureVersions = () => {
        QuestionService.GetQuestionsStructureVersions((data: IQuestionStructureVersion[]) => {
            var qsvs: IQuestionStructureVersion[] = data;
            console.log(qsvs, 'qsvs');

            var ddOptions: IDropdownOption[] = [];
            qsvs.map((questionStructureVersion: IQuestionStructureVersion) => {
                ddOptions.push({ key: questionStructureVersion.id.toString(), text: questionStructureVersion.version })

            });
            setQuestionsStructureVersions(qsvs);

            // if (selectedOrganizationId !== null) {
            //     updateSystems(parseInt(selectedOrganizationId, 10));
            // }

        });
    }

    // const handleSystemSelection = (system: ISystem) => {
    //     console.log(system, 'system');
    //     navigate("/system/" + system.systemId);
    //     //props.history.push("/system/123s");
    // }

    // const updateQuestions = (questionStructureVersionId: number) => {
    //     console.log(questionStructureVersionId, 'questionStructureVersionId');

    //     setQuestions([]);
    //     QuestionService.GetQuestionsByStructureVersionId(questionStructureVersionId, (data: IQuestion[]) => {
    //         var qs: IQuestion[] = data;

    //         fixQuestionData(qs);
    //         function sortByGroupOrder(a: IQuestion, b: IQuestion) {
    //             if (a.group!.id === b.group!.id) {
    //                 return b.order - a.order;
    //             }
    //             return a.group!.order > b.group!.order ? 1 : -1;
    //         }

    //         qs.sort(sortByGroupOrder);

    //         console.log(qs, 'qs');
    //         setQuestions(qs);

    //     });

    //     //navigate("/system/" + system.systemId);
    //     //props.history.push("/system/123s");
    // }

    // const fixQuestionData = (questions: IQuestion[]) => {
    //     questions.forEach((question: IQuestion) => {
    //         if (question.questionStructures.length === 1)
    //             question.group = question.questionStructures[0].group;
    //     });
    // }


    // const onQuestionsStructureVersionChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
    //     setSelectedQuestionsStructureVersion(item);
    //     //localStorage.setItem('selectedOrganizationId', item.key.toString());
    //     updateQuestions(parseInt(item.key.toString()));
    // };

    // const _items: ICommandBarItemProps[] = [
    //     {
    //         key: 'newQuestionDomain',
    //         text: 'Opret spørgeramme',
    //         cacheKey: 'myCacheKey', // changing this key will invalidate this item's cache
    //         iconProps: { iconName: 'Add' },
    //         onClick: () => navigate("/questionstructure")

    //     },
    //     // {
    //     //     key: 'editQuestionDomain',
    //     //     text: 'Rediger spørgeskema',
    //     //     cacheKey: 'myCacheKey', // changing this key will invalidate this item's cache
    //     //     iconProps: { iconName: 'Edit' },
    //     //     onClick: () => navigate("/questionstructure/" + selectedQuestionsStructureVersion?.key?.toString())

    //     // },
    //     // {
    //     //     key: 'editItem',
    //     //     text: 'Edit',
    //     //     iconProps: { iconName: 'Edit' },
    //     // },
    // ];

    const loadCommandBarQuestionItems = () => {
        var items: ICommandBarItemProps[] = [];
        if (userHasPermissions(["All.Create", "Questions.Create"], props.currentUser)) {
            items.push({
                key: 'newQuestion',
                text: 'Opret spørgsmål',
                cacheKey: 'myCacheKey', // changing this key will invalidate this item's cache
                iconProps: { iconName: 'Add' },
                onClick: () => setIsQuestionPanelOpen(true)
            })
        }
        setCommandBarQuestionItems(items)
    };

    const loadCommandBarQSVItems = () => {
        var items: ICommandBarItemProps[] = [];
        if (userHasPermissions(["All.Create", "Questions.Create"], props.currentUser)) {
            items.push({
                key: 'newQuestionDomain',
                text: 'Opret spørgeramme',
                cacheKey: 'myCacheKey', // changing this key will invalidate this item's cache
                iconProps: { iconName: 'Add' },
                onClick: () => navigate("/questionstructure")

            })
        }
        setCommandBarQSVItems(items)
    };

    // const _farItems: ICommandBarItemProps[] = [
    //     {
    //         key: 'tile',
    //         text: 'Grid view',
    //         // This needs an ariaLabel since it's icon-only
    //         ariaLabel: 'Grid view',
    //         iconOnly: true,
    //         iconProps: { iconName: 'BulletedList' },
    //         onClick: () => console.log('Tiles'),
    //     },
    //     {
    //         key: 'tile',
    //         text: 'Grid view',
    //         // This needs an ariaLabel since it's icon-only
    //         ariaLabel: 'Grid view',
    //         iconOnly: true,
    //         iconProps: { iconName: 'GroupList' },
    //         onClick: () => console.log('Tiles'),
    //     },
    //     {
    //         key: 'info',
    //         text: 'Info',
    //         // This needs an ariaLabel since it's icon-only
    //         ariaLabel: 'Info',
    //         iconOnly: true,
    //         iconProps: { iconName: 'Info' },
    //         onClick: () => console.log('Info'),
    //     },
    // ];

    // const columns: IColumn[] = [
    //     {
    //         key: 'column1',
    //         name: 'Id',
    //         minWidth: 60,
    //         maxWidth: 60,
    //         isResizable: true,
    //         //onColumnClick: this._onColumnClick,
    //         data: 'string',
    //         onRender: (question: IQuestion) => {
    //             return <span>{question.questionId}</span>;
    //         },
    //     },
    //     {
    //         key: 'column0',
    //         name: 'Gruppe',
    //         minWidth: 150,
    //         maxWidth: 150,
    //         isResizable: true,
    //         //onColumnClick: this._onColumnClick,
    //         data: 'string',
    //         onRender: (question: IQuestion) => {
    //             return <span >{question.group !== undefined ? question.group!.name : ''}</span>;
    //         },
    //     },

    //     {
    //         key: 'column3',
    //         name: 'Type',
    //         minWidth: 70,
    //         maxWidth: 90,
    //         isResizable: true,
    //         //onColumnClick: this._onColumnClick,
    //         data: 'string',
    //         onRender: (question: IQuestion) => {
    //             return <span>{question.type!.name}</span>;
    //         },
    //     },

    //     {
    //         key: 'column2',
    //         name: 'Spørgsmål',
    //         fieldName: 'name',
    //         minWidth: 210,
    //         maxWidth: 350,
    //         isRowHeader: true,
    //         isResizable: true,
    //         //   onColumnClick: this._onColumnClick,
    //         onRender: (question: IQuestion) => {
    //             return <span style={{ cursor: 'pointer' }} >{question.question1}</span>;
    //         },
    //         data: 'string',
    //         isPadded: true,
    //     }
    // ];

    const loadQuestionColumns = () => {


        const _columns: IColumn[] = [
            {
                key: 'column0',
                name: '',
                minWidth: 50,
                maxWidth: 50,
                isResizable: true,
                data: 'string',
                onRender: (question: IQuestion) => {
                    return (
                        <>
                            {userHasPermissions(["All.Update", "Questions.Update"], props.currentUser) && (
                                <span><Icon style={{ cursor: 'pointer', fontSize: '16px' }} iconName="Edit" onClick={() => handleEditQuestion(question)} /></span>
                            )}
                            {userHasPermissions(["All.Update", "Questions.Update"], props.currentUser) && (
                                <>{question.questionStructures.length === 0 ?

                                    <span><Icon style={{ cursor: 'pointer', fontSize: '16px', marginLeft: '10px' }} iconName="Delete" onClick={() => handleDeleteQuestion(question)} /></span>
                                    : <span><Icon style={{ fontSize: '16px', marginLeft: '10px', color: '#ddd' }} iconName="Delete" title='Spørgsmålet kan ikke slettes da det indgår i en spørgeramme' /></span>
                                }</>)}
                        </>

                    );
                },
            },
            {
                key: 'column1',
                name: 'Id',
                fieldName: 'questionId',
                minWidth: 80,
                maxWidth: 80,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (question: IQuestion) => {
                    return <span>{question.questionId}</span>;
                },
            },
            {
                key: 'column2',
                name: 'Type',
                fieldName: 'typeId',
                minWidth: 40,
                maxWidth: 40,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (question: IQuestion) => {
                    return <span>
                        {question.typeId === 1 ? <Icon iconName='Remove' title={question.type!.name} /> :
                            question.typeId === 2 ? <Icon iconName='GlobalNavButton' title={question.type!.name} /> :
                                question.typeId === 3 ? <Icon iconName='Sort' title={question.type!.name} /> :
                                    question.typeId === 4 ? <Icon iconName='CheckboxComposite' title={question.type!.name} /> :
                                        question.typeId === 5 ? <Icon iconName='NumberSymbol' title={question.type!.name} /> :
                                            question.typeId === 8 ? <Icon iconName='Calendar' title={question.type!.name} /> :
                                                question.typeId === 6 ? <Icon iconName='UserFollowed' title={question.type!.name} /> : ''}
                    </span>;
                },
            },

            {
                key: 'column3',
                name: 'Spørgsmål',
                fieldName: 'question1',
                minWidth: 310,
                maxWidth: 350,
                isRowHeader: true,
                isResizable: true,
                //   onColumnClick: this._onColumnClick,
                onRender: (question: IQuestion) => {
                    return <span className='cursor-pointer'>{question.question1}</span>;
                },
                data: 'string',
                isPadded: true,
            },
            {
                key: 'column4',
                name: 'Sensitivt',
                fieldName: 'classified',
                minWidth: 100,
                maxWidth: 100,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (question: IQuestion) => {
                    return <span>{question.classified ? 'Ja' : 'Nej'}</span>;
                },
            },
            {
                key: 'column5',
                name: 'Anvendelse i antal spørgerammer',
                minWidth: 100,
                maxWidth: 1000,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (question: IQuestion) => {
                    return <span>{question.questionStructures.length}</span>;
                },
            },
        ];
        setQuestionsColumns(_columns);
    }

    const handleEditQuestion = (question: IQuestion) => {

        setEditingQuestion(question);

        setQuestion(question.question1);
        setQuestionId(question.questionId);
        setDescription(question.description);
        setTags(question.tags);
        setRelatedQuestionIds(question.relatedQuestionIds);
        setClassified(question.classified);
        //loadQuestionTypeOptions(questionTypes, question.typeId);


        if (question.typeId === 3) {
            var optionsValue = '';

            question?.questionOptions.forEach((option: IQuestionOption) => {
                optionsValue += option.option + '\n';
            });

            setSelectedQuestionOptions(optionsValue);
            setInitialQuestionOptions(question?.questionOptions);
        }

        setIsQuestionPanelOpen(true);


    }

    const handleDeleteQuestion = (question: IQuestion) => {

        setIsConfirmDialogOpen(true);

        setSelectedQuestion(question)

        // QuestionService.DeleteQuestion(questionId, (data: boolean) => {
        //     var success: boolean = data;
        //     console.log(success);


        //     loadQuestions();
        // })
    }

    const confirmDeleteQuestion = () => {
        QuestionService.DeleteQuestion(selectedQuestion!.id, (data: boolean) => {
            var success: boolean = data;
            console.log(success);

            setIsConfirmDialogOpen(false);
            setSelectedQuestion(null);

            if (success) {
                loadQuestions();

                toast.info('Spørgsmålet blev slettet!', {
                    position: "top-center",
                    autoClose: 3000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: 0,
                    theme: "light",
                    transition: Bounce,
                });
            }
            else {
                toast.error('Spørgsmålet kan ikke slettes - Det indgår formentligt i en spørgeramme eller har besvarelser!', {
                    position: "top-center",
                    autoClose: 6000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: 0,
                    theme: "colored",
                    transition: Bounce,
                });
            }


        })
    }
    const loadQSVColumns = () => {
        const columns: IColumn[] = [
            {
                key: 'column0',
                name: '',
                minWidth: 50,
                maxWidth: 50,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (qsv: IQuestionStructureVersion) => {
                    return (
                        <>
                            {userHasPermissions(["All.Update", "Questions.Update"], props.currentUser) && (
                                <span><Icon style={{ cursor: 'pointer', fontSize: '16px' }} iconName="Edit" onClick={() => navigate("/questionstructure/" + qsv.id)} /></span>
                            )}
                            {userHasPermissions(["All.Delete", "Questions.Delete"], props.currentUser) && (
                                <span><Icon style={{ cursor: 'pointer', fontSize: '16px', marginLeft: '10px' }} iconName="Delete" onClick={() => handleDeleteQSV(qsv.id)} /></span>
                            )}
                        </>);
                },
            },
            {
                key: 'column1',
                name: 'Titel',
                fieldName: 'version',
                minWidth: 300,
                maxWidth: 300,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (qsv: IQuestionStructureVersion) => {
                    return <span>{qsv.version}</span>;
                },
            },
            {
                key: 'column2',
                name: 'Status',
                fieldName: 'enabled',
                minWidth: 80,
                maxWidth: 80,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (qsv: IQuestionStructureVersion) => {
                    return <span>{qsv.enabled ? 'Aktiv' : 'Inaktiv'}</span>;
                },
            },
            {
                key: 'column3',
                name: 'Opdateret',
                minWidth: 120,
                maxWidth: 120,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (qsv: IQuestionStructureVersion) => {
                    return <span>{format(qsv.modified, 'dd.MM.yyyy HH:mm')}</span>;
                },
            },
            {
                key: 'column4',
                name: 'Scope',
                fieldName: 'scope',
                minWidth: 250,
                maxWidth: 250,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (qsv: IQuestionStructureVersion) => {
                    return <span>{qsv.scope}</span>;
                },
            },
            {
                key: 'column5',
                name: 'Type',
                fieldName: 'type',
                minWidth: 200,
                maxWidth: 200,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (qsv: IQuestionStructureVersion) => {
                    return <span>{qsv.type}</span>;
                },
            },


        ];
        setQSVColumns(columns);
    }

    const handleDeleteQSV = (qsvId: number) => {

        QuestionService.DeleteQuestionStructureVersion(qsvId, (data: boolean) => {
            var success: boolean = data;
            console.log(success);


            loadQuestionsStructureVersions();
        })
    }

    const _getKey = (item: any): string => {
        return item.key;
    }

    const saveQuestion = () => {
        console.log('Save question');

        //console.log(editorRef !== null && editorRef.current !== null && editorRef.current.getContent());

        var questionOptions: IQuestionOption[] = [];

        if (selectedQuestionType === "3") {
            var separateLines = selectedQuestionOptions.split(/\r?\n|\r|\n/g);

            separateLines.forEach((option: string, index: number) => {

                if (option.length > 0) {
                    var knownOption = initialQuestionOptions.filter((o: IQuestionOption) => o.option === option)

                    questionOptions.push({
                        id: knownOption.length === 1 ? knownOption[0].id : 0,
                        option: option,
                        order: index
                    })
                }
            });
        }

        var q: IQuestion = {
            id: editingQuestion !== null ? editingQuestion.id : 0,
            question1: question,
            questionId: questionId,
            description: mceValue,
            typeId: parseInt(selectedQuestionType, 10),
            tags: tags,
            classified: classified,
            relatedQuestionIds: relatedQuestionIds,
            enabled: true,
            questionOptions: questionOptions,
            type: null,
            group: null,
            order: 0,
            questionStructures: [],
            structureversion: 0
        };

        QuestionService.SaveQuestion(q, (data: number) => {
            console.log(data);
            //alert('saved with id: ' + data);

            if (data > 0) {
                clearQuestionPanelValues();
                setEditingQuestion(null);
                setIsQuestionPanelOpen(false);

                loadQuestions();

                toast.info('Spørgsmål blev gemt!', {
                    position: "top-center",
                    autoClose: 3000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: 0,
                    theme: "light",
                    transition: Bounce,
                });

            }
            if (data === -2) {
                toast.error(`Der findes allerede et spørgsmål med id: ${questionId}!`, {
                    position: "top-center",
                    autoClose: 3000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: 0,
                    theme: "light",
                    transition: Bounce,
                });
            }

        });
    }

    const clearQuestionPanelValues = () => {
        setEditingQuestion(null);

        setQuestion('');
        setQuestionId('');
        setDescription('');
        setTags('');
        setRelatedQuestionIds('');
        setSelectedQuestionType('');
        setSelectedQuestionOptions('');
        setClassified(false);
        setQuestionIdCollision(false);
    }

    const onRenderQuestionTypeOption = (option: IDropdownOption | undefined): JSX.Element => {
        return (
            <div>
                {option!.data && option!.data.icon && (
                    <Icon style={iconStyles} iconName={option!.data.icon} aria-hidden="true" title={option!.data.icon} />
                )}
                <span>{option!.text}</span>
            </div>
        );
    };

    const renderQuestionPanel = () => {

        return (
            <Panel
                headerText={editingQuestion === null ? "Opret spørgsmål" : "Rediger spørgsmål"}
                isOpen={isQuestionPanelOpen}
                onDismiss={() => {
                    setIsQuestionPanelOpen(false);
                    clearQuestionPanelValues();
                }
                }
                // You MUST provide this prop! Otherwise screen readers will just say "button" with no label.
                closeButtonAriaLabel="Close"
                type={PanelType.medium}
            >
                <div className='question-panel-wrapper'>
                    <TextField
                        className='question-panel-item'
                        value={question}
                        onChange={(value: any) => setQuestion(value.target.value)}
                        label='Spørgsmål'></TextField>
                    <div className='panel-header'>Beskrivelse</div>
                    <Editor
                        tinymceScriptSrc={'../tinymce/tinymce.min.js'}
                        onInit={(editor: any) => editorRef.current = editor}
                        onChange={(value: any) => {
                            console.log(value.level.content);
                            setMCEValue(value.level.content);
                        }}
                        initialValue={description}
                        init={{
                            height: 240,
                            menubar: false,
                            statusbar: false,
                            plugins: [
                                'advlist', 'autolink', 'lists', 'link', 'image', 'charmap',
                                'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
                                'insertdatetime', 'media', 'table', 'preview', 'help', 'wordcount'
                            ],
                            toolbar: 'undo redo | bold italic underline | bullist numlist outdent indent | removeformat',
                            content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
                        }}
                    />
                    {/* <TextField
                        className='question-panel-item'
                        label='Beskrivelse'
                        value={description}
                        onChange={(value: any) => setDescription(value.target.value)}
                        multiline
                        rows={3}></TextField> */}
                    <TextField
                        className='question-panel-item'
                        value={questionId}
                        onChange={(value: any) => {
                            setQuestionId(value.target.value)
                            if (questions.filter((q: IQuestion) => (q.id > 0 && q.questionId === value.target.value && editingQuestion?.id !== q.id) || (editingQuestion === null && q.questionId === value.target.value)).length > 0) {
                                console.log('COLLISION!')
                                setQuestionIdCollision(true);
                            }
                            else {
                                setQuestionIdCollision(false);
                            }
                        }}
                        // }
                        // onBlur={(value: any) => {

                        // }}
                        label='Spørgsmål id'></TextField>
                    {questionIdCollision && (<div className='question-panel-questionid-collision'>Spørgsmål id findes allerede!</div>)}
                    <Dropdown
                        label="Type"
                        placeholder="Vælg type..."
                        options={getQuestionTypeOptions(questionTypes, editingQuestion !== null ? editingQuestion?.typeId : 0)} //{questionTypeOptions}
                        styles={dropdownStyles}
                        className='question-panel-item'
                        onRenderOption={onRenderQuestionTypeOption}
                        onChange={(_event, value) => setSelectedQuestionType(value!.key.toString())}
                    />
                    {((editingQuestion !== null && editingQuestion.typeId === 3) || (selectedQuestionType === '3')) && (
                        <TextField
                            className='question-panel-item'
                            label='Valg'
                            placeholder='Angiv 1 valg pr. linie i den ønskede rækkefølge'
                            multiline rows={7}
                            value={selectedQuestionOptions}
                            onChange={(value: any) => setSelectedQuestionOptions(value.target.value)}
                        ></TextField>
                    )}
                    <TextField
                        className='question-panel-item'
                        label='Tags'
                        value={tags}
                        onChange={(value: any) => setTags(value.target.value)}
                    ></TextField>
                    <TextField
                        className='question-panel-item'
                        label='Relation til andrespørgsmål'
                        value={relatedQuestionIds}
                        onChange={(value: any) => setRelatedQuestionIds(value.target.value)}
                        placeholder="Angiv spørgsmåls id'er på relaterede spørgsmål i CSV format (Q01,Q02,Q03)"
                    ></TextField>
                    <Stack tokens={stackTokens}>
                        <Checkbox
                            checked={classified}
                            className='question-panel-item-checkbox'
                            label='Sensitivt'
                            onChange={(_event: any, value: any) => setClassified(value)}
                        ></Checkbox>


                    </Stack>
                    <DefaultButton
                        className='question-panel-savebutton'
                        onClick={() => saveQuestion()}
                        disabled={question.length === 0 || questionId.length === 0 || selectedQuestionType.length === 0}
                    >

                        {editingQuestion === null ? "Gem" : "Opdater"}
                    </DefaultButton>



                </div>
            </Panel >
        )

    }

    const renderConfirmDialog = () => {

        const modalProps = React.useMemo(
            () => ({
                titleAriaId: 'title',
                subtitleAriaId: 'subtitle',
                isBlocking: false,
                styles: dialogStyles,
                dragOptions: undefined,
            }),
            [],
        );


        return (
            <Dialog
                hidden={!isConfirmDialogOpen}
                onDismiss={() => setIsConfirmDialogOpen(false)}
                dialogContentProps={dialogContentProps}
                modalProps={modalProps}
                minWidth={550}
            >
                <DialogContent>
                    Du er ved at slette et spørgsmål.<br />
                    Denne handling vil ikke kunne fortrydes hvis du fortsætter.<br />
                    <br />
                    Vil du fortsætte?
                </DialogContent>
                <DialogFooter>
                    <PrimaryButton style={{ width: '240px' }} onClick={() => confirmDeleteQuestion()} text="Ja" />
                    <DefaultButton style={{ width: '240px' }} onClick={() => setIsConfirmDialogOpen(false)} text="Nej" />
                </DialogFooter>
            </Dialog>
        )
    }

    const handleQuestionSorting = (ev?: React.MouseEvent<HTMLElement>, column?: IColumn): void => {
        if (column?.fieldName !== null && column?.fieldName !== undefined) {
            const newColumns: IColumn[] = questionsColumns.slice();
            const currColumn: IColumn = newColumns.filter(currCol => column?.key === currCol.key)[0];
            newColumns.forEach((newCol: IColumn) => {
                if (newCol === currColumn) {
                    currColumn.isSortedDescending = !currColumn.isSortedDescending;
                    currColumn.isSorted = true;
                    // this.setState({
                    //   announcedMessage: `${currColumn.name} is sorted ${
                    //     currColumn.isSortedDescending ? 'descending' : 'ascending'
                    //   }`,
                    // });
                } else {
                    newCol.isSorted = false;
                    newCol.isSortedDescending = true;
                }
            });
            const newQuestions = f_sort(filteredQuestions, currColumn.fieldName!, currColumn.isSortedDescending);  // _copyAndSort(filteredQuestions, currColumn.fieldName!, currColumn.isSortedDescending);

            setQuestionsColumns(newColumns);
            setFilteredQuestions(newQuestions);
        }
    };

    const handleQSVSorting = (ev?: React.MouseEvent<HTMLElement>, column?: IColumn): void => {
        if (column?.fieldName !== null && column?.fieldName !== undefined) {
            const newColumns: IColumn[] = qsvColumns.slice();
            const currColumn: IColumn = newColumns.filter(currCol => column?.key === currCol.key)[0];
            newColumns.forEach((newCol: IColumn) => {
                if (newCol === currColumn) {
                    currColumn.isSortedDescending = !currColumn.isSortedDescending;
                    currColumn.isSorted = true;
                    // this.setState({
                    //   announcedMessage: `${currColumn.name} is sorted ${
                    //     currColumn.isSortedDescending ? 'descending' : 'ascending'
                    //   }`,
                    // });
                } else {
                    newCol.isSorted = false;
                    newCol.isSortedDescending = true;
                }
            });
            const newQSVs = f_sort(questionsStructureVersions, currColumn.fieldName!, currColumn.isSortedDescending);  // _copyAndSort(filteredQuestions, currColumn.fieldName!, currColumn.isSortedDescending);

            setQSVColumns(newColumns);
            setQuestionsStructureVersions(newQSVs);
        }
    };

    function f_sort(dataArg: any[], colName: string, isSortedDescending?: boolean) {

        dataArg.sort(function (res01, res02) {
            var arg01 = res01[colName] !== null ? res01[colName].toString().toLowerCase() : '';
            var arg02 = res02[colName] != null ? res02[colName].toString().toLowerCase() : '';
            if (arg01 < arg02) { return isSortedDescending ? 1 : -1; }
            if (arg01 > arg02) { return !isSortedDescending ? 1 : -1 }
            return 0;
        });
        return dataArg;
    }

    // function _copyAndSort<T>(items: T[], columnKey: string, isSortedDescending?: boolean): T[] {
    //     const key = columnKey as keyof T;
    //     return items.slice(0).sort((a: T, b: T) => ((isSortedDescending ? a[key] < b[key] : a[key] > b[key]) ? 1 : -1));
    // }

    return (
        <>
            {userHasPermissions(["All.Read", "Questions.Read"], props.currentUser) && (

                <div>
                    <div className='module-header'>Spørgsmål og spørgerammer</div>
                    <Pivot aria-label="Basic Pivot Example">
                        <PivotItem headerText="Spørgsmål">
                            <div className='module-header-spacer'>
                                <CommandBar
                                    items={commandBarQuestionItems}
                                />
                                <DetailsList
                                    items={filteredQuestions}
                                    columns={questionsColumns}
                                    setKey="single"
                                    getKey={_getKey}
                                    layoutMode={DetailsListLayoutMode.justified}
                                    isHeaderVisible={true}
                                    selection={_selection}
                                    selectionPreservedOnEmptyClick={true}
                                    selectionMode={SelectionMode.none}
                                    onColumnHeaderClick={(ev?: React.MouseEvent<HTMLElement>, column?: IColumn) => handleQuestionSorting(ev, column)}
                                />
                            </div>
                        </PivotItem>
                        <PivotItem headerText="Spørgerammer">
                            <div className='module-header-spacer'>
                                <CommandBar
                                    items={commandBarQSVItems}
                                />
                                <DetailsList
                                    items={questionsStructureVersions}
                                    columns={qsvColumns}
                                    setKey="single"
                                    getKey={_getKey}
                                    layoutMode={DetailsListLayoutMode.justified}
                                    isHeaderVisible={true}
                                    selection={_selection}
                                    selectionPreservedOnEmptyClick={true}
                                    selectionMode={SelectionMode.none}
                                    onColumnHeaderClick={(ev?: React.MouseEvent<HTMLElement>, column?: IColumn) => handleQSVSorting(ev, column)}
                                />
                            </div>
                        </PivotItem>
                    </Pivot>
                    {renderQuestionPanel()}
                    {renderConfirmDialog()}
                    <ToastContainer />
                </div >
            )
            }
        </>
    )
}

export default Questions;
