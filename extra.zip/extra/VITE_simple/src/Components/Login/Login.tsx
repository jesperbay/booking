import { Button, DefaultButton, IIconProps, Icon, TextField } from '@fluentui/react';
import './Login.css'
import React, { useEffect, useState } from 'react';
import { IUser } from '../Interfaces';
import AuthService from '../../Services/AuthService';

const { Config } = (window as any)["Config"];

const windowsIcon: IIconProps = { iconName: 'WindowsLogo' };

function Login(props: any) {
    const [username, setUsername] = useState<string>('');
    const [password, setPassword] = useState<string>('');
    const [AuthType] = useState<string>(Config.AuthType);

    const handleLogin = () => {
        console.log(username + '-' + password);

        props.login(username, 'GDSFD', '', (success: boolean) => {
            if (!success) {
                alert('Invalid username/password!');
            }
        });
    }

    const handleWindowsLogin = () => {
        props.handleWindowsLogin((success: boolean) => {
            if (success) {
                console.log('Windows login success!');
            }
        });
    }

    // // useEffect hook to clear local storage on component mount
    // useEffect(() => {
    //     localStorage.removeItem("lexi-token");
    // }, []); // Empty dependency array ensures the effect runs only once on component mount

    return (
        <div className='login-wrapper'>
            <div>
                <TextField placeholder='Brugernavn...' onChange={(value: any) => setUsername(value.target.value)} />
                <TextField placeholder='Password...' type='password' onChange={(value: any) => setPassword(value.target.value)} />
                <DefaultButton className='login-button' onClick={() => handleLogin()}>Login</DefaultButton>

            </div>
            {AuthType === 'HYBRID' && (
                <div className='windows-login'>
                    <DefaultButton iconProps={windowsIcon} className='login-button' onClick={() => handleWindowsLogin()}>Windows login</DefaultButton>
                </div>
            )}
        </div>
    )
}

export default Login;
