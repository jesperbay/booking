
import * as React from 'react';
import './Menu.css'
import { Icon } from '@fluentui/react';
import { useNavigate, useLocation } from 'react-router-dom';
import { IUser } from '../Interfaces';
import { userHasPermissions } from '../Providers/PermissionWrapper';
import metadata from '../../buildnumber.json';

export interface IHeaderProps {
    user: IUser | undefined;
}

function Menu(props: IHeaderProps) {
    let navigate = useNavigate();

    const location = useLocation();



    return (
        <>
            {props.user !== null && props.user !== undefined && (
                <div className='menu-wrapper'>
                    <div className='menu-content-wrapper'>
                        <>
                            {userHasPermissions(["All.Read", "Systems.View"], props.user) && (
                                <div className={`menu-item ${location.pathname === "/systems" ? 'active' : ''}`} onClick={() => navigate("/duties")}>
                                    <Icon className="menu-item-icon" iconName="Calendar" />
                                    <div className="menu-item-label">Vagter</div>
                                </div>
                            )}
                            {/* 
                            {userHasPermissions(["All.Read", "Questions.Read"], props.user) && (
                                <div className={`menu-item ${location.pathname === "/questions" ? 'active' : ''}`} onClick={() => navigate("/questions")}>
                                    <Icon className="menu-item-icon" iconName="StatusCircleQuestionMark" />
                                    <div className="menu-item-label">Spørgsmål</div>
                                </div>
                            )}
                            {userHasPermissions(["All.Read", "Suppliers.Read"], props.user) && (
                                <div className={`menu-item ${location.pathname === "/suppliers" ? 'active' : ''}`} onClick={() => navigate("/suppliers")}>
                                    <Icon className="menu-item-icon" iconName="EMI" />
                                    <div className="menu-item-label">Leverandører</div>
                                </div>
                            )}
                            {userHasPermissions(["All.Read", "Users.Read"], props.user) && (
                                <div className={`menu-item ${location.pathname === "/users" ? 'active' : ''}`} onClick={() => navigate("/users")}>
                                    <Icon className="menu-item-icon" iconName="ContactInfo" />
                                    <div className="menu-item-label">Brugere</div>
                                </div>
                            )} */}
                            {userHasPermissions(["All.Read", "Users.Read"], props.user) && (
                                <div className={`menu-item ${location.pathname === "/users" ? 'active' : ''}`} onClick={() => navigate("/users")}>
                                    <Icon className="menu-item-icon" iconName="ContactInfo" />
                                    <div className="menu-item-label">Brugere</div>
                                </div>
                            )}

                        </>
                    </div>
                    <div className='product-version'>{`v ${metadata.buildMajor}.${metadata.buildMinor}.${metadata.buildRevision} ${metadata.buildTag}`}</div>
                </div >
            )
            }
        </>
    )
}

export default Menu
