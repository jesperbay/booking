import { useEffect, useState } from "react";
import * as React from "react";
import { ISystem, IOrganization, IUser, ISupplier, ISystemSupplier, ISupplierRole } from "../Interfaces";
import SystemService from "../../Services/SystemService";
import OrganizationService from "../../Services/OrganizationService";
import {
  CommandBar,
  Selection,
  DetailsList,
  DetailsListLayoutMode,
  Dropdown,
  IColumn,
  ICommandBarItemProps,
  IDropdownOption,
  IDropdownStyles,
  Icon,
  SelectionMode,
  TextField,
  PrimaryButton,
  DefaultButton,
  Panel,
  PanelType,
  Checkbox,
} from "@fluentui/react";
import { useNavigate } from "react-router-dom";
import "./Systems.css";
import { userHasPermissions } from "../Providers/PermissionWrapper";
import UserService from "../../Services/UserService";
import SupplierService from "../../Services/SupplierService";
import { Bounce, ToastContainer, toast } from "react-toastify";

const dropdownStyles: Partial<IDropdownStyles> = {
  dropdown: { width: "100%" },
};

const dropdownStatusList = [
  { key: "Draft", text: "Kladde" },
  { key: "Active", text: "Aktiv" },
  { key: "Removed", text: "Nedlagt" },
  { key: "Deleted", text: "Slettet" },
];

function Systems(props: any) {
  const [systems, setSystems] = React.useState<ISystem[]>([]);
  const [_filteredSystems, setFilteredSystems] = React.useState<ISystem[]>([]);
  const [selectedSystem, setSelectedSystem] = React.useState<ISystem | null>(null);

  const [organizations, setOrganizations] = React.useState<IOrganization[]>([]);
  const [selectedOrganization, setSelectedOrganization] = React.useState<IDropdownOption>();
  const [organizationOptions, setOrganizationOptions] = React.useState<IDropdownOption[]>([]);
  const [editSystemOpen, setEditSystemOpen] = React.useState<boolean>(false);
  const [editSystemUsersOpen, setEditSystemUsersOpen] = React.useState<boolean>(false);
  const [selectedItems, setSelectedItems] = useState<ISystem[]>([]);
  const [_selectedUsers, setSelectedUsers] = useState<IUser[]>([]);
  const [commandBarItems, setCommandBarItems] = useState<ICommandBarItemProps[]>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");
  const [systemName, setSystemName] = React.useState<string>("");
  const [systemDescription, setSystemDescription] = React.useState<string>("");
  const [addUserPremission, setAddUserPremission] = React.useState<boolean>(false);
  const [_userRead, setUserRead] = useState<boolean>(false);
  const [_userUpdate, setUserUpdate] = useState<boolean>(false);
  const [_userApprove, setUserApprove] = useState<boolean>(false);
  const [userIsValid, setUserIsValid] = React.useState<string>("unknown");
  const [validatedUser, setValidatedUser] = React.useState<IUser | null>(null);
  const [isValidatingUser, setIsValidatingUser] = React.useState<boolean>(false);
  const [_tempValue, setTempValue] = React.useState<string>("");
  const [systemOwner, setSystemOwner] = React.useState<string>("");
  const [addSystemUser, setAddSystemUser] = React.useState<string>("");
  const [addSupplierPanelOpen, setAddSupplierPanelOpen] = React.useState<boolean>(false);
  const [suppliers, setSuppliers] = useState<ISupplier[]>([]);
  const [supplierRoles, setSupplierRoles] = useState<ISupplierRole[]>([]);
  const [selectedSystemSuppliers, setSelectedSystemSuppliers] = useState<ISystemSupplier[]>([]);
  const [_filteredSuppliers, setFilteredSuppliers] = useState<ISupplier[]>([]);
  const [showSupplierSelector, setShowSupplierSelector] = React.useState<boolean>(false);
  const [supplierOptions, setSupplierOptions] = React.useState<IDropdownOption[]>([]);
  const [supplierRoleOptions, setSupplierRoleOptions] = React.useState<IDropdownOption[]>([]);
  const [selectedSupplier, setSelectedSupplier] = React.useState<IDropdownOption>();
  const [selectedSupplierRole, setSelectedSupplierRole] = React.useState<IDropdownOption>();
  const [systemsColumns, setSystemsColumns] = React.useState<IColumn[]>([]);

  const [_selection] = useState(
    new Selection({
      onSelectionChanged: () => {
        setSelectedItems(_selection.getSelection() as ISystem[]);
      },
    }),
  );

  const [_selectionForUsers] = useState(
    new Selection({
      onSelectionChanged: () => {
        setSelectedUsers(_selectionForUsers.getSelection() as IUser[]);
      },
    }),
  );

  let navigate = useNavigate();

  useEffect(() => {
    if (props.currentUser !== null && props.currentUser !== undefined) {
      if (systems!.length === 0) {
        handleLoadSystems(false);
      }
      if (suppliers.length === 0) {
        loadSuppliers();
      }
      if (supplierRoles.length === 0) {
        loadSupplierRoles();
      }

      if (systemsColumns.length === 0) {
        loadColumns();
      }
    }
  }, [props.currentUser]);

  useEffect(() => {
    console.log("selected system trigger");
    loadCommandBarItems();
  }, [selectedItems]);

  /*   useEffect(() => {
    if (selectedUsers.length > 0) {
      const user: any = getSystemPermissions(selectedUsers[0]);
      console.log(selectedUsers, "user");
      console.log(user, "user");
      setUserApprove(false);
      setUserUpdate(false);
      setUserRead(false);
      if (user.includes("Approve")) {
        setUserApprove(true);
      }
      if (user.includes("Update")) {
        setUserUpdate(true);
      }
      if (user.includes("Read")) {
        setUserRead(true);
      } else {
        setUserApprove(false);
        setUserUpdate(false);
        setUserRead(false);
      }
    }
  }, [selectedUsers, addUserPremission]); */

  const handleLoadSystems = (force: boolean) => {
    if (userHasPermissions(["All.Read", "Systems.Read"], props.currentUser)) {
      if (organizations.length === 0 || force) {
        loadOrganizations();
      }
    } else {
      loadMySystems();
    }
  };

  const loadMySystems = () => {
    SystemService.GetMySystems((data: ISystem[]) => {
      var ss: ISystem[] = data;
      setSystems(ss);
      setFilteredSystems(ss);
      loadSystemOrganizations(ss);

      _selection.setItems([]);
      setSelectedItems([]);
    });
  };

  const loadOrganizations = () => {
    OrganizationService.GetOrganizations((data: IOrganization[]) => {
      var os: IOrganization[] = data;
      var selectedOrganizationId: string | null = localStorage.getItem("selectedOrganizationId");
      var ddOptions: IDropdownOption[] = [];
      os.map((organization: IOrganization) => {
        if (selectedOrganizationId !== null && selectedOrganizationId === organization.id.toString()) {
          ddOptions.push({ key: organization.id.toString(), text: organization.name, selected: true });
          setSelectedOrganization({ key: organization.id.toString(), text: organization.name, selected: true });
        } else ddOptions.push({ key: organization.id.toString(), text: organization.name });
      });
      setOrganizationOptions(ddOptions);
      setOrganizations(os);

      if (selectedOrganizationId !== null) {
        updateSystems(parseInt(selectedOrganizationId, 10));
      }
    });
  };

  const loadSystemOrganizations = (ss: ISystem[]) => {
    var os: IOrganization[] = [];
    ss.forEach((s: ISystem) => {
      const matchingOrganization = os.find((o: IOrganization) => o.id === s.organization!.id);
      if (!matchingOrganization) {
        os.push(s.organization!);
      }
    });

    var selectedOrganizationId: string | null = localStorage.getItem("selectedOrganizationId");

    var ddOptions: IDropdownOption[] = [];
    os.map((organization: IOrganization) => {
      if (selectedOrganizationId !== null && selectedOrganizationId === organization.id.toString()) {
        ddOptions.push({ key: organization.id.toString(), text: organization.name, selected: true });
        setSelectedOrganization({ key: organization.id.toString(), text: organization.name, selected: true });
      } else ddOptions.push({ key: organization.id.toString(), text: organization.name });
    });
    setOrganizationOptions(ddOptions);
    setOrganizations(os);

    if (selectedOrganizationId !== null) {
      filterSystems(ss, parseInt(selectedOrganizationId, 10));
    }
  };

  const loadSuppliers = () => {
    SupplierService.GetSuppliers((data: ISupplier[]) => {
      var ss: ISupplier[] = data;
      setSuppliers(ss);
      setFilteredSuppliers(ss);

      var ddOptions: IDropdownOption[] = [];
      ddOptions.push({ key: "0", text: "Vælg leverandør" });
      ss.map((supplier: ISupplier) => {
        ddOptions.push({ key: supplier.id.toString(), text: supplier.name });
      });
      setSupplierOptions(ddOptions);
    });
  };

  const loadSupplierRoles = () => {
    SupplierService.GetSupplierRoles((data: ISupplierRole[]) => {
      var sr: ISupplierRole[] = data;
      setSupplierRoles(sr);

      var ddOptions: IDropdownOption[] = [];
      ddOptions.push({ key: "0", text: "Vælg Leverandørrolle" });
      sr.map((supplierRole: ISupplierRole) => {
        ddOptions.push({ key: supplierRole.id.toString(), text: supplierRole.role });
      });
      setSupplierRoleOptions(ddOptions);
    });
  };

  const filterSuppliers = (ss: ISystem) => {
    if (ss !== null) {
      var ddOptions: IDropdownOption[] = [];
      ddOptions.push({ key: "0", text: "Vælg leverandør" });
      suppliers.map((supplier: ISupplier) => {
        var alreadyAddedSuppliers = ss.systemSuppliers.filter((ss: ISystemSupplier) => ss.supplierId === supplier.id);
        if (alreadyAddedSuppliers.length === 0) ddOptions.push({ key: supplier.id.toString(), text: supplier.name });
      });
      setSupplierOptions(ddOptions);
    }
  };

  const handleManageSystemSuppliers = (ss: ISystem) => {
    console.log("handleManageSystemSuppliers");
    setAddSupplierPanelOpen(true);
    filterSuppliers(ss);

    console.log(ss);
    if (ss !== null) {
      //var systemSuppliers: ISupplier[] | undefined = ss?.systemSuppliers.map((ss: ISystemSupplier) => { return ss.supplier });

      setSelectedSystemSuppliers(ss?.systemSuppliers);
    }
  };

  const loadCommandBarItems = () => {
    let _items: ICommandBarItemProps[] = [];

    if (userHasPermissions(["All.Create", "Systems.Create"], props.currentUser)) {
      if (selectedItems.length === 1) {
        _items.push({
          key: "editItem",
          text: "Administrer system",
          iconProps: { iconName: "Edit" },
          onClick: () => setEditSystemOpen(true),
          cacheKey: "myCacheKey", // changing this key will invalidate this item's cache
        });
        _items.push({
          key: "supplier",
          text: "Administrer leverandører",
          iconProps: { iconName: "EMI" },
          onClick: () => {
            handleManageSystemSuppliers(selectedItems[0]);
          },
          cacheKey: "myCacheKey", // changing this key will invalidate this item's cache
        });
        _items.push({
          key: "Users",
          text: "Administrer brugere",
          iconProps: { iconName: "People" },
          onClick: () => setEditSystemUsersOpen(true),
          cacheKey: "myCacheKey", // changing this key will invalidate this item's cache
        });

        console.log(selectedItems[0]);
        setSelectedSystem(selectedItems[0]);
        setSystemDescription(selectedItems[0].description);
        setSystemName(selectedItems[0].name);
        setSystemOwner(selectedItems[0].owner?.stabsnr!);
        setSelectedStatus(selectedItems[0].status!);
        setUserIsValid("valid");
        let stabsnr = users.filter((user) => user.id === selectedItems[0].ownerId);
        if (stabsnr.length > 0) setTempValue(stabsnr[0].stabsnr);
        loadUsers();
      } else {
        _items.push({
          key: "newItem",
          text: "Nyt system",
          cacheKey: "myCacheKey", // changing this key will invalidate this item's cache
          iconProps: { iconName: "Add" },
          onClick: () => {
            setSystemDescription("");
            setSystemName("");
            setSystemOwner("");
            setUserIsValid("unknown");
            setEditSystemOpen(true);
          },
        });

        setSelectedSystem(null);
      }
    }
    setCommandBarItems(...[_items]);
  };

  const handleSystemSelection = (system: ISystem) => {
    console.log(system, "system");
    navigate("/system/" + system.systemId);
    //props.history.push("/system/123s");
  };

  const updateSystems = (organizationId: number) => {
    setSystems([]);
    setFilteredSystems([]);
    SystemService.GetSystemByOrganizationId(organizationId, (data: ISystem[]) => {
      var ss: ISystem[] = data;
      setSystems(ss);
      setFilteredSystems(ss);

      _selection.setItems([]);
      setSelectedItems([]);
    });
  };

  const filterSystems = (ss: ISystem[], organizationId: number) => {
    setFilteredSystems([]);
    var filteredSystems = ss.filter((s: ISystem) => s.organization!.id === organizationId);
    setFilteredSystems(filteredSystems);
  };

  const saveSystem = () => {
    var s: ISystem = {
      id: selectedItems.length > 0 ? selectedItems[0].id : 0,
      name: systemName,
      description: systemDescription,
      created: new Date(),
      createdBy: null,
      createdById: props.currentUser.id,
      modified: new Date(),
      modifiedBy: null,
      modifiedById: props.currentUser.id,
      iterations: [],
      owner: null,
      ownerId: validatedUser !== null ? validatedUser.id : selectedItems[0].ownerId,
      status: selectedStatus,
      organization: null,
      organizationId: parseInt(selectedOrganization!.key.toString(), 10),
      systemSuppliers: [],
      systemUsers: [],
    };

    SystemService.SaveSystem(s, (data: ISystem) => {
      var s: ISystem = data;
      console.log(s, "s");
      setEditSystemOpen(false);

      var selectedOrganizationId: string | null = localStorage.getItem("selectedOrganizationId");

      if (selectedOrganizationId !== null) {
        updateSystems(parseInt(selectedOrganizationId, 10));
      }
    });
  };

  const onOrganizationChange = (
    event: React.FormEvent<HTMLDivElement>,
    item: IDropdownOption<any> | undefined,
    _index: number | undefined,
  ): void => {
    setSelectedOrganization(item);
    localStorage.setItem("selectedOrganizationId", item!.key.toString());

    if (userHasPermissions(["All.Read", "Systems.Read"], props.currentUser)) {
      updateSystems(parseInt(item!.key.toString()));
    } else {
      filterSystems(systems!, parseInt(item!.key.toString()));
    }
    console.log(event);
  };

  const onStatusChange = (
    _event: React.FormEvent<HTMLDivElement>,
    option: IDropdownOption<any> | undefined,
    _index: number | undefined,
  ): void => {
    if (option) {
      setSelectedStatus(option.text!);
    }
  };

  const onSupplierChange = (
    _event: React.FormEvent<HTMLDivElement>,
    item: IDropdownOption<any> | undefined,
    _index: number | undefined,
  ): void => {
    setSelectedSupplier(item);
  };

  const onSupplierRoleChange = (
    _event: React.FormEvent<HTMLDivElement>,
    item: IDropdownOption<any> | undefined,
    _index: number | undefined,
  ): void => {
    setSelectedSupplierRole(item);
  };

  const _userItem: ICommandBarItemProps[] = [
    {
      key: "newuser",
      text: "Tilføj bruger",
      iconOnly: false,
      iconProps: { iconName: "Add" },
      onClick: () => {
        console.log("tilføj bruger"), setAddUserPremission(true);
      },
    },
  ];

  const handleColumnSorting = (ev?: React.MouseEvent<HTMLElement>, column?: IColumn): void => {
    if (column?.fieldName !== null && column?.fieldName !== undefined) {
      const newColumns: IColumn[] = systemsColumns.slice();
      const currColumn: IColumn = newColumns.filter((currCol) => column?.key === currCol.key)[0];
      newColumns.forEach((newCol: IColumn) => {
        if (newCol === currColumn) {
          currColumn.isSortedDescending = !currColumn.isSortedDescending;
          currColumn.isSorted = true;
          // this.setState({
          //   announcedMessage: `${currColumn.name} is sorted ${
          //     currColumn.isSortedDescending ? 'descending' : 'ascending'
          //   }`,
          // });
        } else {
          newCol.isSorted = false;
          newCol.isSortedDescending = true;
        }
      });
      const newSystems = f_sort(systems, currColumn.fieldName!, currColumn.isSortedDescending); //_copyAndSort(systems, currColumn.fieldName!, currColumn.isSortedDescending);

      setSystemsColumns(newColumns);
      setSystems(newSystems);
    }
  };

  function f_sort(dataArg: any[], colName: string, isSortedDescending?: boolean) {
    dataArg.sort(function (res01, res02) {
      var arg01 = res01[colName] !== null ? res01[colName].toString().toLowerCase() : "";
      var arg02 = res02[colName] != null ? res02[colName].toString().toLowerCase() : "";
      if (arg01 < arg02) {
        return isSortedDescending ? 1 : -1;
      }
      if (arg01 > arg02) {
        return !isSortedDescending ? 1 : -1;
      }
      return 0;
    });
    return dataArg;
  }

  // function _copyAndSort<T>(items: ISystem[], columnKey: string, isSortedDescending?: boolean): ISystem[] {
  //   const key = columnKey as keyof T;

  //   items.sort((a: ISystem, b: ISystem) => a[columnKey] - b[columnKey]);

  //   var tempItems = items.sort((a: ISystem, b: ISystem) => ((isSortedDescending ? a["columnKey"] < b[columnKey] : a[columnKey] > b[columnKey]) ? 1 : -1));
  //   return tempItems
  // }

  const loadColumns = () => {
    const columns: IColumn[] = [
      {
        key: "column0",
        name: "Status",
        fieldName: "status",
        minWidth: 50,
        maxWidth: 50,
        isResizable: true,
        data: "string",
        onRender: (system: ISystem) => {
          return <span className={`systems-statusbox ${system.status.toUpperCase()}`}>{system.status}</span>;
        },
      },
      {
        key: "column1",
        name: "Id",
        fieldName: "systemId",
        minWidth: 60,
        maxWidth: 60,
        isResizable: true,
        data: "string",
        onRender: (system: ISystem) => {
          return <span>{system.systemId}</span>;
        },
        //onColumnClick: (ev: React.MouseEvent<HTMLElement>, column: IColumn) => handleColumnSorting("id", systems, systemsColumns),
      },
      {
        key: "column2",
        name: "System",
        fieldName: "name",
        minWidth: 210,
        maxWidth: 350,
        isRowHeader: true,
        isResizable: true,
        isSorted: true,
        isSortedDescending: false,
        sortAscendingAriaLabel: "Sorted A to Z",
        sortDescendingAriaLabel: "Sorted Z to A",
        onRender: (system: ISystem) => {
          return (
            <span className="system-selection-column" onClick={() => handleSystemSelection(system)}>
              {system.name}
            </span>
          );
        },
        //onColumnClick: () => handleColumnSorting("id", systems, systemsColumns),
        data: "string",
        isPadded: true,
      },

      // {
      //   key: "column3",
      //   name: "Iterationer",
      //   minWidth: 70,
      //   maxWidth: 90,
      //   isResizable: true,
      //   data: "string",
      //   onRender: (system: ISystem) => {
      //     return <span>{system.iterations.length}</span>;
      //   },
      // },
      {
        key: "column4",
        name: "Leverandører",
        fieldName: "name",
        minWidth: 70,
        maxWidth: 90,
        isResizable: true,
        //onColumnClick: this._onColumnClick,
        data: "string",
        onRender: (system: ISystem) => {
          return (
            <span>
              {system.systemSuppliers !== null && system.systemSuppliers !== undefined && system.systemSuppliers.length}
            </span>
          );
        },
      },
    ];

    setSystemsColumns(columns);
  };

  const supplierColumns: IColumn[] = [
    {
      key: "column0",
      name: "",
      minWidth: 50,
      maxWidth: 50,
      onRender: (ss: ISystemSupplier) => {
        return (
          <Icon iconName="Delete" onClick={() => handleRemoveSupplier(ss.supplierId)} style={{ cursor: "pointer" }} />
        );
      },
    },
    {
      key: "column1",
      name: "Leverandør",
      minWidth: 200,
      maxWidth: 200,
      isResizable: true,
      data: "string",
      onRender: (ss: ISystemSupplier) => {
        return <span>{ss.supplier.name}</span>;
      },
    },
    {
      key: "column2",
      name: "Rolle",
      minWidth: 200,
      maxWidth: 200,
      isResizable: true,
      data: "string",
      onRender: (ss: ISystemSupplier) => {
        return <span>{ss.supplierRole.role}</span>;
      },
    },
  ];

  const cleartextboxes = () => {
    setSystemName("");
    setSystemDescription("");
    setTempValue("");
  };

  const handleAddSupplier = () => {
    console.log("handleAddSupplier");

    console.log("SystemId: " + selectedSystem?.id);
    console.log("SupplierId: " + selectedSupplier?.key);

    SystemService.AddSupplier(
      selectedSystem!.id,
      Number(selectedSupplier!.key),
      Number(selectedSupplierRole!.key),
      (success: boolean) => {
        if (success) {
          setShowSupplierSelector(false);
          setAddSupplierPanelOpen(false);

          toast.success("Leverandør tilknyttet!", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: 0,
            theme: "light",
            transition: Bounce,
          });

          handleLoadSystems(true);
        } else {
          toast.success("Tilknytning af leverandør fejlede!", {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: 0,
            theme: "light",
            transition: Bounce,
          });
        }

        setSelectedSupplierRole({ key: "0", text: "Vælg Leverandørrolle" });
        setSelectedSupplier({ key: "0", text: "Vælg Leverandør" });
      },
    );
  };

  const handleRemoveSupplier = (supplierId: number) => {
    console.log("handleRemoveSupplier");

    console.log("SystemId: " + selectedSystem?.id);
    console.log("SupplierId: " + supplierId);

    SystemService.RemoveSupplier(selectedSystem!.id, supplierId, (success: boolean) => {
      //alert('Supplier removed!');

      if (success) {
        setShowSupplierSelector(false);
        setAddSupplierPanelOpen(false);

        toast.success("Leverandør tilknytning fjernet!", {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: 0,
          theme: "light",
          transition: Bounce,
        });

        handleLoadSystems(true);
      } else {
        toast.success("Leverandør kan ikke fjernes!", {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: 0,
          theme: "light",
          transition: Bounce,
        });
      }
    });
  };

  const onRenderSystemContent = () => {
    return (
      <div>
        <PrimaryButton
          onClick={() => (setEditSystemOpen(false), cleartextboxes(), saveSystem())}
          style={{ marginRight: "8px" }}
          disabled={userIsValid !== "valid" ? true : false}
        >
          {selectedItems.length > 0 ? "Gem ændringer" : "Opret system"}
        </PrimaryButton>
        <DefaultButton onClick={() => (setEditSystemOpen(false), cleartextboxes())}>Luk</DefaultButton>
      </div>
    );
  };

  // const onRenderAddSupplierContent = () => {
  //   return (
  //     <div>
  //       <PrimaryButton onClick={() => setAddSupplierPanelOpen(false)} style={{ marginRight: "8px" }}>
  //         {"Tilknyt leverandør"}
  //       </PrimaryButton>
  //       <DefaultButton onClick={() => setAddSupplierPanelOpen(false)}>Luk</DefaultButton>
  //     </div>
  //   );
  // };

  const renderEditSystemPanel = () => {
    return (
      <div>
        <Panel
          type={PanelType.medium}
          isOpen={editSystemOpen}
          onDismiss={() => (setEditSystemOpen(false), cleartextboxes())}
          headerText={selectedItems.length > 0 ? "Edit system" : "Register system"}
          closeButtonAriaLabel="Luk"
          onRenderFooterContent={onRenderSystemContent}
          isFooterAtBottom={true}
        >
          <div className="editsystem-modal-content">
            <div className="editsystem-modal-content-row">
              <div className="editsystem-modal-content-label">Title</div>
              <div className="editsystem-modal-content-field">
                <TextField
                  spellCheck={false}
                  value={systemName}
                  onChange={(value: any) => setSystemName(value.target.value)}
                ></TextField>
              </div>
            </div>
            <div className="editsystem-modal-content-row">
              <div className="editsystem-modal-content-label">Beskrivelse</div>
              <div className="editsystem-modal-content-field">
                <TextField
                  multiline
                  rows={5}
                  spellCheck={false}
                  value={systemDescription}
                  onChange={(value: any) => setSystemDescription(value.target.value)}
                ></TextField>
              </div>
            </div>
            <div className="editsystem-modal-content-row">
              <div className="editsystem-modal-content-label">System ansvarlig</div>
              <div className="editsystem-modal-content-field">
                <div className="question-answer-userwrapper">
                  <TextField
                    className={`question-answer-userinput ${userIsValid} `}
                    spellCheck={false}
                    value={systemOwner}
                    onChange={(value: any) => {
                      setSystemOwner(value.target.value);
                      setUserIsValid("unknown");
                    }}
                  />
                  {!isValidatingUser ? (
                    <Icon
                      iconName="UserFollowed"
                      className={`question-answer-usercheck`}
                      onClick={() => {
                        setIsValidatingUser(true);
                        UserService.ValidateUsername(systemOwner, true, (user: any) => {
                          if (user !== null && user !== "") {
                            setUserIsValid("valid");
                            setSystemOwner(user.lastName + " (" + user.email + ") - ");
                            setValidatedUser(user);
                          } else {
                            setUserIsValid("invalid");
                            setValidatedUser(null);
                            //setSystemOwner("")
                          }
                          setIsValidatingUser(false);
                        });
                      }}
                    />
                  ) : (
                    <Icon className={`question-answer-usercheck`} iconName="Clock" />
                  )}
                </div>
              </div>
            </div>
            {selectedItems.length > 0 ? (
              <div className="editsystem-modal-content-row">
                <div className="editsystem-modal-content-label">Systems status</div>
                <div className="editsystem-modal-content-field">
                  <Dropdown
                    placeholder={selectedItems.length > 0 ? selectedItems[0].status : "Vælg Status"}
                    options={dropdownStatusList}
                    styles={dropdownStyles}
                    // eslint-disable-next-line react/jsx-no-bind
                    onChange={onStatusChange}
                  />
                </div>
              </div>
            ) : (
              <></>
            )}
          </div>
        </Panel>
      </div>
    );
  };

  const renderAddSupplierPanel = () => {
    const commandBarSupplierItems = [
      {
        key: "addSupplier",
        text: "Tilknyt leverandør",
        iconProps: { iconName: "Add" },
        onClick: () => {
          setShowSupplierSelector(true);
          filterSuppliers(selectedSystem!);
        },
        cacheKey: "myCacheKey", // changing this key will invalidate this item's cache
      },
    ];

    return (
      <div>
        <Panel
          type={PanelType.medium}
          isOpen={addSupplierPanelOpen}
          onDismiss={() => setAddSupplierPanelOpen(false)}
          headerText={"Administrer leverandører"}
          closeButtonAriaLabel="Luk"
        >
          <div className="addSupplier-modal-content">
            <div className="addSupplier-modal-content-row">
              <div className="addSupplier-modal-content-label">
                {showSupplierSelector && (
                  <>
                    <Dropdown
                      placeholder="Vælg leverandør"
                      selectedKey={selectedSupplier ? selectedSupplier.key : undefined}
                      options={supplierOptions}
                      styles={dropdownStyles}
                      style={{ marginTop: "20px" }}
                      // eslint-disable-next-line react/jsx-no-bind
                      onChange={onSupplierChange}
                    />

                    <Dropdown
                      placeholder="Vælg leverandørrole"
                      selectedKey={selectedSupplierRole ? selectedSupplierRole.key : undefined}
                      options={supplierRoleOptions}
                      styles={dropdownStyles}
                      style={{ marginTop: "20px" }}
                      // eslint-disable-next-line react/jsx-no-bind
                      onChange={onSupplierRoleChange}
                    />

                    <div>
                      <DefaultButton
                        style={{ marginTop: "20px" }}
                        onClick={() => handleAddSupplier()}
                        disabled={
                          (selectedSupplier! && selectedSupplier!.key === "0") ||
                          (selectedSupplierRole! && selectedSupplierRole!.key === "0")
                        }
                      >
                        Tilknyt leverandør
                      </DefaultButton>
                      <DefaultButton style={{ marginLeft: "20px" }} onClick={() => setShowSupplierSelector(false)}>
                        Anuller
                      </DefaultButton>
                    </div>
                  </>
                )}

                {!showSupplierSelector && (
                  <>
                    <CommandBar items={commandBarSupplierItems} />
                    <DetailsList
                      items={selectedSystemSuppliers!}
                      columns={supplierColumns}
                      setKey="single"
                      layoutMode={DetailsListLayoutMode.justified}
                      isHeaderVisible={true}
                      selection={_selectionForUsers}
                      selectionPreservedOnEmptyClick={true}
                      selectionMode={SelectionMode.none}
                    />
                  </>
                )}
              </div>
            </div>
          </div>
        </Panel>
      </div>
    );
  };

  const onRenderSystemUsersContent = () => {
    return (
      <div>
        {addUserPremission !== false ? (
          <>
            <PrimaryButton
              disabled={userIsValid !== "valid" ? true : false}
              onClick={() => {
                AddUserToSystem();
                setAddUserPremission(false);
                setAddSystemUser("");
              }}
              style={{ marginRight: "8px", marginLeft: "auto" }}
            >
              Gem
            </PrimaryButton>
            <DefaultButton onClick={() => setAddUserPremission(false)}>Luk</DefaultButton>
          </>
        ) : (
          <></>
        )}
      </div>
    );
  };

  const userColumn: IColumn[] = [
    {
      key: "column0",
      name: "",
      minWidth: 10,
      maxWidth: 10,
      onRender: (user: IUser) => {
        return (
          <div>
            <Icon
              iconName="Delete"
              onClick={() => {
                console.log("delete");
                removePermissionFromUser(user.id, selectedItems[0].id, 5);
              }}
              style={{ cursor: "pointer", color: "red" }}
            />
          </div>
        );
      },
    },
    {
      key: "column1",
      name: "Navn",
      minWidth: 150,
      maxWidth: 150,
      isResizable: true,
      data: "string",
      onRender: (user: IUser) => {
        return (
          <span>
            {user.firstName} {user.lastName}
          </span>
        );
      },
    },
    {
      key: "column3",
      name: "Stabsnr",
      fieldName: "name",
      minWidth: 90,
      maxWidth: 90,
      isRowHeader: true,
      isResizable: true,
      onRender: (user: IUser) => {
        return <span>{user.stabsnr}</span>;
      },
    },
    {
      key: "column4",
      name: "Systemer",
      fieldName: "name",
      minWidth: 250,
      maxWidth: 250,
      isRowHeader: true,
      isResizable: true,
      onRender: (user: IUser) => {
        return (
          <div className="panel-content-row">
            <Checkbox
              disabled={true}
              label="Læs"
              checked={
                user.systemUsers.some((systemUser) => systemUser.permission.name === "Systems.Read") &&
                user.systemUsers.some((systemUser) => systemUser.system.id === selectedItems[0].id)
              }
              onChange={(_ev, _isChecked) => console.log("læs")}
              styles={{ root: { marginRight: "10px" } }}
            />
            <Checkbox
              label="Opdater"
              checked={
                user.systemUsers.some((systemUser) => systemUser.permission.name === "Systems.Update") &&
                user.systemUsers.some((systemUser) => systemUser.system.id === selectedItems[0].id)
              }
              onChange={(_ev, isChecked) => {
                if (isChecked) {
                  console.log("opdater" + " " + user.id + " " + user.systemUsers[0].system.id + " " + 6);
                  addPermissionToUser(user.id, selectedItems[0].id, 6);
                } else {
                  console.log("remove opdater" + " " + user.id + " " + user.systemUsers[0].system.id + " " + 6);
                  removePermissionFromUser(user.id, selectedItems[0].id, 6);
                }
              }}
              styles={{ root: { marginRight: "10px" } }}
            />
            <Checkbox
              label="Godkend"
              checked={
                user.systemUsers.some((systemUser) => systemUser.permission.name === "Systems.Approve") &&
                user.systemUsers.some((systemUser) => systemUser.system.id === selectedItems[0].id)
              }
              onChange={(_ev, isChecked) => {
                if (isChecked) {
                  console.log("godkend" + " " + user.id + " " + user.systemUsers[0].system.id + " " + 9);
                  addPermissionToUser(user.id, selectedItems[0].id, 9);
                } else {
                  console.log("remove godkend" + " " + user.id + " " + user.systemUsers[0].system.id + " " + 9);
                  removePermissionFromUser(user.id, selectedItems[0].id, 9);
                }
              }}
              styles={{ root: { marginRight: "10px" } }}
            />
          </div>
        );
      },
    },
  ];

  // const getSystemPermissions = (user: IUser) => {
  //   var systems: string[] = [];
  //   var permissions: string = "";
  //   {
  //     user.systemUsers.map((systemUser: ISystemUser) => {
  //       var strSystemPermissions: string = "";

  //       if (systems.filter((system: string) => system === systemUser.system.name).length === 0) {
  //         systems.push(systemUser.system.name);

  //         var systemPermissions: ISystemUser[] = user.systemUsers.filter(
  //           (su: ISystemUser) => su.system.name === systemUser.system.name,
  //         );
  //         systemPermissions.forEach((su: ISystemUser) => {
  //           strSystemPermissions += su.permission.name + ", ";
  //         });
  //         strSystemPermissions = strSystemPermissions.substring(0, strSystemPermissions.length - 2);

  //         permissions += systemUser.system.name + " (" + strSystemPermissions + ")" + ", ";
  //       }
  //     });

  //     permissions = permissions.substring(0, permissions.length - 2);
  //   }

  //   return permissions;
  // };

  const [users, setUsers] = React.useState<IUser[]>([]);
  useEffect(() => {
    if (users.length === 0) {
    }
  }, []);

  const loadUsers = () => {
    UserService.GetUsers((data: IUser[]) => {
      var users: IUser[] = data;
      setUsers(
        users.filter((user) => user.systemUsers.some((systemUser) => systemUser.system.id === selectedItems[0].id)),
      );
    });
  };

  const clearUserCheckbox = () => {
    setUserRead(false);
    setUserUpdate(false);
    setUserApprove(false);
  };

  const renderEditSystemUsersPanel = () => {
    return (
      <div>
        <Panel
          type={PanelType.medium}
          isOpen={editSystemUsersOpen}
          onDismiss={() => {
            setEditSystemUsersOpen(false), clearUserCheckbox(), setAddUserPremission(false);
          }}
          headerText="System brugere"
          closeButtonAriaLabel="Luk"
          onRenderFooterContent={onRenderSystemUsersContent}
          isFooterAtBottom={true}
        >
          <div>
            {addUserPremission === false ? (
              <div>
                <CommandBar items={_userItem} ariaLabel="Inbox actions" />
                <div>
                  <DetailsList
                    items={users}
                    columns={userColumn}
                    setKey="single"
                    layoutMode={DetailsListLayoutMode.justified}
                    isHeaderVisible={true}
                    selection={_selectionForUsers}
                    selectionPreservedOnEmptyClick={true}
                    selectionMode={SelectionMode.none}
                  />
                </div>
              </div>
            ) : (
              <div>
                <div>
                  <div className="editUserpermissions-panel-content-field">
                    <div className="question-answer-userwrapper">
                      <TextField
                        className={`question-answer-userinput ${userIsValid} `}
                        spellCheck={false}
                        value={addSystemUser}
                        onChange={(value: any) => {
                          setAddSystemUser(value.target.value);
                          setUserIsValid("unknown");
                        }}
                      />
                      {!isValidatingUser ? (
                        <Icon
                          iconName="UserFollowed"
                          className={`question-answer-usercheck`}
                          onClick={() => {
                            setIsValidatingUser(true);
                            UserService.ValidateUsername(addSystemUser, true, (user: any) => {
                              if (user !== null && user !== "") {
                                setUserIsValid("valid");
                                setAddSystemUser(user.lastName + " (" + user.email + ") ");
                                setValidatedUser(user);
                              } else {
                                setUserIsValid("invalid");
                                setValidatedUser(null);
                              }
                              setIsValidatingUser(false);
                            });
                          }}
                        />
                      ) : (
                        <Icon className={`question-answer-usercheck`} iconName="Clock" />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </Panel>
      </div>
    );
  };

  const AddUserToSystem = () => {
    var u: any = {
      systemId: selectedSystem!.id,
      userId: validatedUser!.id,
      permissionId: 5,
    };

    UserService.AddUserToSystem(u.userId, u.systemId, u.permissionId, (data: any) => {
      var u: any = data;
      console.log(u, "u");
      loadUsers();
      setAddUserPremission(false);
    });
  };

  const addPermissionToUser = (userid: number, systemId: number, permissionId: number) => {
    console.log(userid, systemId, permissionId);
    UserService.AddUserToSystem(userid, systemId, permissionId, (data: any) => {
      var u: any = data;
      console.log(u, "u");
      loadUsers();
      setAddUserPremission(false);
    });
  };

  const removePermissionFromUser = (userid: number, systemId: number, permissionId: number) => {
    console.log(userid, systemId, permissionId);
    UserService.RemoveUserFromSystem(userid, systemId, permissionId, (data: any) => {
      var u: any = data;
      console.log(u, "u");
      loadUsers();
      setAddUserPremission(false);
    });
  };

  // const _getKey = (item: any, index?: number): string => {
  //   return item.id;
  // };

  return (
    <>
      {userHasPermissions(["All.Read", "Systems.View"], props.currentUser) && (
        <div>
          <div className="module-header-spacer">
            {userHasPermissions(["All.Read", "Systems.Read"], props.currentUser) && <>Systemer</>}
            {!userHasPermissions(["All.Read", "Systems.Read"], props.currentUser) && <>Dine systemer</>}
          </div>
          {userHasPermissions(["All.Read", "Systems.View"], props.currentUser) && organizationOptions.length > 0 && (
            <Dropdown
              placeholder="Vælg myndighed"
              selectedKey={selectedOrganization ? selectedOrganization.key : undefined}
              options={organizationOptions}
              styles={dropdownStyles}
              // eslint-disable-next-line react/jsx-no-bind
              onChange={onOrganizationChange}
            />
          )}
          {systems.length > 0 && (
            <div>
              <CommandBar
                items={commandBarItems}
                ariaLabel="Inbox actions"
                primaryGroupAriaLabel="Email actions"
                farItemsGroupAriaLabel="More actions"
              />
              <DetailsList
                items={systems}
                columns={systemsColumns}
                setKey="single"
                layoutMode={DetailsListLayoutMode.justified}
                isHeaderVisible={true}
                selection={_selection}
                selectionPreservedOnEmptyClick={true}
                selectionMode={SelectionMode.single}
                onColumnHeaderClick={(ev?: React.MouseEvent<HTMLElement>, column?: IColumn) =>
                  handleColumnSorting(ev, column)
                }
              />
              {renderEditSystemPanel()}
              {renderEditSystemUsersPanel()}
              {renderAddSupplierPanel()}

              {/* {JSON.stringify(selectedSystem!)} */}
            </div>
          )}
          {userHasPermissions(["All.Read"], props.currentUser) && organizations.length === 0 && (
            <div>Vælg myndighed...</div>
          )}
        </div>
      )}
      <ToastContainer />
    </>
  );
}

export default Systems;
