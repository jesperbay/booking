import { useEffect, useState } from 'react'
import * as React from 'react';
import { DetailsList, DetailsListLayoutMode, IColumn, ICommandBarItemProps, SelectionMode, CommandBar, Panel, PanelType, TextField, DefaultButton, Icon, Dialog, DialogContent, DialogFooter, PrimaryButton, DialogType } from '@fluentui/react';
import './Suppliers.css'
import { ISupplier } from '../Interfaces';
import { userHasPermissions } from '../Providers/PermissionWrapper';
import SupplierService from '../../Services/SupplierService';
import { Bounce, ToastContainer, toast } from 'react-toastify';

const dialogContentProps = {
    type: DialogType.normal,
    title: 'Bekræft sletning',
    closeButtonAriaLabel: 'Close',
    subText: '',
};

const dialogStyles = { main: { maxWidth: 450 } };

function Suppliers(props: any) {
    const [suppliers, setSuppliers] = useState<ISupplier[]>([])
    const [isSupplierPanelOpen, setIsSupplierPanelOpen] = useState<boolean>(false);
    const [editingSupplier, setEditingSupplier] = useState<ISupplier | null>(null)
    const [selectedSupplier, setSelectedSupplier] = useState<ISupplier | null>(null)
    const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState<boolean>(false);
    const [supplierName, setSupplierName] = useState<string>('');
    const [suppliersColumns, setSuppliersColumns] = useState<IColumn[]>([]);

    useEffect(() => {
        console.log('Initial useEffect');

        // if (systems.length === 0) {
        //     loadSystems();
        // }
        if (suppliers.length === 0) {
            loadSuppliers();
        }

        if (suppliersColumns.length === 0) {
            loadColumns();
        }
    }, [])

    const loadSuppliers = () => {
        SupplierService.GetSuppliers((data: ISupplier[]) => {
            var ss: ISupplier[] = data;


            //            fixUsersData(users);
            // function sortByGroupOrder(a: IQuestion, b: IQuestion) {
            //     if (a.group.id === b.group.id) {
            //         // Price is only important when cities are the same
            //         return b.order - a.order;
            //     }
            //     return a.group.order > b.group.order ? 1 : -1;
            // }

            // qs.sort(sortByGroupOrder);

            console.log(ss, 'suppliers');
            setSuppliers(ss);

        });
    }

    const loadColumns = () => {
        const columns: IColumn[] = [
            {
                key: 'column0',
                name: '',
                minWidth: 50,
                maxWidth: 50,
                isResizable: true,
                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (supplier: ISupplier) => {
                    return (
                        <>
                            <span><Icon style={{ cursor: 'pointer', fontSize: '16px' }} iconName="Edit" onClick={() => handleEditSupplier(supplier)} /></span>
                            {supplier.systemSuppliers.length === 0 ?

                                <span><Icon style={{ cursor: 'pointer', fontSize: '16px', marginLeft: '10px' }} iconName="Delete" onClick={() => handleDeleteSupplier(supplier)} /></span>
                                : <span><Icon style={{ fontSize: '16px', marginLeft: '10px', color: '#ddd' }} iconName="Delete" title='Leverandør kan ikke slettes - Den er formentligt aktiv på et system!' /></span>
                            }
                        </>);
                },
            },
            {
                key: 'column1',
                name: 'Navn',
                fieldName: 'name',
                minWidth: 150,
                maxWidth: 150,
                isResizable: true,
                isSorted: true,
                isSortedDescending: false,
                sortAscendingAriaLabel: "Sorted A to Z",
                sortDescendingAriaLabel: "Sorted Z to A",

                //onColumnClick: this._onColumnClick,
                data: 'string',
                onRender: (supplier: ISupplier) => {
                    return <span>{supplier.name}</span>;
                },
            }
        ];
        setSuppliersColumns(columns);
    }

    const handleColumnSorting = (ev?: React.MouseEvent<HTMLElement>, column?: IColumn): void => {
        if (column?.fieldName !== null && column?.fieldName !== undefined) {
            const newColumns: IColumn[] = suppliersColumns.slice();
            const currColumn: IColumn = newColumns.filter(currCol => column?.key === currCol.key)[0];
            newColumns.forEach((newCol: IColumn) => {
                if (newCol === currColumn) {
                    currColumn.isSortedDescending = !currColumn.isSortedDescending;
                    currColumn.isSorted = true;
                    // this.setState({
                    //   announcedMessage: `${currColumn.name} is sorted ${
                    //     currColumn.isSortedDescending ? 'descending' : 'ascending'
                    //   }`,
                    // });
                } else {
                    newCol.isSorted = false;
                    newCol.isSortedDescending = true;
                }
            });
            const sortedUsers = f_sort(suppliers, currColumn.fieldName!, currColumn.isSortedDescending); //_copyAndSort(systems, currColumn.fieldName!, currColumn.isSortedDescending);

            setSuppliersColumns(newColumns);
            setSuppliers(sortedUsers);
        }

    };

    function f_sort(dataArg: any[], colName: string, isSortedDescending?: boolean) {

        dataArg.sort(function (res01, res02) {
            var arg01 = res01[colName] !== null ? res01[colName].toString().toLowerCase() : '';
            var arg02 = res02[colName] != null ? res02[colName].toString().toLowerCase() : '';
            if (arg01 < arg02) { return isSortedDescending ? 1 : -1; }
            if (arg01 > arg02) { return !isSortedDescending ? 1 : -1 }
            return 0;
        });
        return dataArg;
    }

    const commandBarSupplierItems: ICommandBarItemProps[] = [
        {
            key: 'newSupplier',
            text: 'Opret leverandør',
            cacheKey: 'myCacheKey', // changing this key will invalidate this item's cache
            iconProps: { iconName: 'Add' },
            onClick: () => setIsSupplierPanelOpen(true)

        }
    ];

    const handleEditSupplier = (supplier: ISupplier) => {

        setEditingSupplier(supplier);

        setSupplierName(supplier.name);

        setIsSupplierPanelOpen(true);


    }

    const handleDeleteSupplier = (supplier: ISupplier) => {
        console.log('handleDeleteSupplier');


        setIsConfirmDialogOpen(true);

        setSelectedSupplier(supplier)

        // QuestionService.DeleteQuestion(questionId, (data: boolean) => {
        //     var success: boolean = data;
        //     console.log(success);


        //     loadQuestions();
        // })
    }

    const confirmDeleteSupplier = () => {
        SupplierService.DeleteSupplier(selectedSupplier!.id, (data: boolean) => {
            var success: boolean = data;
            console.log(success);

            setIsConfirmDialogOpen(false);
            setSelectedSupplier(null);

            if (success) {
                loadSuppliers();

                toast.info('Leverandør blev slettet!', {
                    position: "top-center",
                    autoClose: 3000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: 0,
                    theme: "light",
                    transition: Bounce,
                });
            }
            else {
                toast.error('Leverandør kan ikke slettes - Den er formentligt aktiv på et system!', {
                    position: "top-center",
                    autoClose: 6000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: 0,
                    theme: "colored",
                    transition: Bounce,
                });
            }


        })
    }


    const saveSupplier = () => {
        console.log('Save saveSupplier');

        var s: ISupplier = {
            id: editingSupplier !== null ? editingSupplier.id : 0,
            name: supplierName,
            systemSuppliers: []
        };

        SupplierService.SaveSupplier(s, (data: number) => {
            console.log(data);
            //alert('saved with id: ' + data);

            setSupplierName('')
            setEditingSupplier(null);
            setIsSupplierPanelOpen(false);

            loadSuppliers();

            toast.info('Leverandør blev gemt!', {
                position: "top-center",
                autoClose: 3000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: 0,
                theme: "light",
                transition: Bounce,
            });
        });
    }

    const renderSupplierPanel = () => {

        return (
            <Panel
                headerText={editingSupplier === null ? "Opret leverandør" : "Rediger leverandør"}
                isOpen={isSupplierPanelOpen}
                onDismiss={() => {
                    setEditingSupplier(null);

                    setSupplierName('');
                    setIsSupplierPanelOpen(false);
                }
                }
                // You MUST provide this prop! Otherwise screen readers will just say "button" with no label.
                closeButtonAriaLabel="Close"
                type={PanelType.medium}
            >
                <div className='question-panel-wrapper'>
                    <TextField
                        className='question-panel-item'
                        value={supplierName}
                        onChange={(value: any) => setSupplierName(value.target.value)}
                        label='Leverandør'></TextField>
                    <DefaultButton
                        className='question-panel-savebutton'
                        onClick={() => saveSupplier()}
                        disabled={supplierName.length === 0}
                    >

                        {editingSupplier === null ? "Gem" : "Opdater"}
                    </DefaultButton>



                </div>
            </Panel >
        )

    }

    const renderConfirmDialog = () => {

        const modalProps = React.useMemo(
            () => ({
                titleAriaId: 'title',
                subtitleAriaId: 'subtitle',
                isBlocking: false,
                styles: dialogStyles,
                dragOptions: undefined,
            }),
            [],
        );


        return (
            <Dialog
                hidden={!isConfirmDialogOpen}
                onDismiss={() => setIsConfirmDialogOpen(false)}
                dialogContentProps={dialogContentProps}
                modalProps={modalProps}
                minWidth={550}
            >
                <DialogContent>
                    Du er ved at slette en leverandør.<br />
                    Denne handling vil ikke kunne fortrydes hvis du fortsætter.<br />
                    <br />
                    Vil du fortsætte?
                </DialogContent>
                <DialogFooter>
                    <PrimaryButton style={{ width: '240px' }} onClick={() => confirmDeleteSupplier()} text="OK" />
                    <DefaultButton style={{ width: '240px' }} onClick={() => setIsConfirmDialogOpen(false)} text="Nej" />
                </DialogFooter>
            </Dialog>
        )
    }



    return (
        <>
            {userHasPermissions(["All.Read", "Suppliers.Read"], props.currentUser) && (

                <div>

                    <div className='module-header-spacer'>Leverandører</div>

                    {suppliers.length > 0 && (
                        <div>
                            <CommandBar
                                items={commandBarSupplierItems}
                            />
                            <DetailsList
                                items={suppliers}
                                columns={suppliersColumns}
                                setKey="single"
                                // getKey={_getKey}
                                layoutMode={DetailsListLayoutMode.justified}
                                isHeaderVisible={true}
                                //selection={_selection}
                                selectionPreservedOnEmptyClick={true}
                                selectionMode={SelectionMode.none}
                                onColumnHeaderClick={(ev?: React.MouseEvent<HTMLElement>, column?: IColumn) => handleColumnSorting(ev, column)}
                            //onItemInvoked={_onItemInvoked}
                            //                        onActiveItemChanged={(item: any) => handleSystemSelection(item)}
                            //selection={handleSystemSelection(this)}
                            //selection={this._selection}
                            //   onItemInvoked={this._onItemInvoked}
                            // enterModalSelectionOnTouch={true}
                            // ariaLabelForSelectionColumn="Toggle selection"
                            // ariaLabelForSelectAllCheckbox="Toggle selection for all items"
                            // checkButtonAriaLabel="select row"
                            />
                            {/* questions */}
                        </div>
                    )}
                    {renderSupplierPanel()}
                    {renderConfirmDialog()}
                    <ToastContainer />
                </div>
            )}
        </>
    )


}

export default Suppliers
