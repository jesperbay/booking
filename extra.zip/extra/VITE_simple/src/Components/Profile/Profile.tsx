
import { Icon } from '@fluentui/react';
import './Profile.css'
import { IPermission, IPermissionRole, ISystem, ISystemUser, IUser, IUserRole } from '../Interfaces';


const { Config } = (window as any)["Config"];

// export interface IHeaderProps {
//     user: IUser | undefined;
// }

function Profile(props: any) {

    const getPermissions = (user: IUser) => {

        var permissions: string = '';
        {
            user.userRoles.map((userRole: IUserRole) => {
                userRole.role.permissionRoles.map((permissionRole: IPermissionRole) => {
                    permissions += permissionRole.permission.name + ', ';
                });
            })

            permissions = permissions.substring(0, permissions.length - 2);
        }

        return permissions;
    }

    const getSystemPermissions = (user: IUser) => {

        console.log(user);
        var systems: string[] = [];
        var permissions: string = '';

        user.systemUsers.map((systemUser: ISystemUser) => {
            var strSystemPermissions: string = '';

            if (systems.filter((system: string) => system === systemUser.system.name).length === 0) {
                systems.push(systemUser.system.name);
                //var tPermission:string = systemUser.permission.name;

                var systemPermissions: ISystemUser[] = user.systemUsers.filter((su: ISystemUser) => su.system.name === systemUser.system.name);
                systemPermissions.forEach((su: ISystemUser) => {
                    strSystemPermissions += su.permission.name + ', ';
                });
                strSystemPermissions = strSystemPermissions.substring(0, strSystemPermissions.length - 2);

                permissions += systemUser.system.name + ' (' + strSystemPermissions + ')' + ', ';
            }
        })

        permissions = permissions.substring(0, permissions.length - 2);

        return permissions;
    }

    const getSystemsAndUserPermissions = (systemUsers: ISystemUser[]) => {

        var systems: ISystem[] = [];
        //var usersAndSystemPermissions: string = '';
        {
            return (
                <>
                    <div className='system-details-meta-systemuser'>
                        <div className='system-details-meta-systemuser-name'></div>
                        <div className='system-details-meta-systemuser-permissions'>
                            <div className='system-details-meta-systemuser-permissions-scope'>Læs</div>
                            <div className='system-details-meta-systemuser-permissions-scope'>Opdater</div>
                            <div className='system-details-meta-systemuser-permissions-scope'>Godkend</div>
                        </div>
                    </div>
                    {systemUsers.map((systemUser: ISystemUser) => {
                        //var strSystemPermissions: string = '';
                        if (systems.filter((system: ISystem) => system.id === systemUser.system.id).length === 0) {
                            systems.push(systemUser.system);
                            //var tPermission:string = systemUser.permission.name;
                            var systemPermissions: ISystemUser[] = systemUsers.filter((su: ISystemUser) => su.system.id === systemUser.system.id);

                            return (<div className='system-details-meta-systemuser'>
                                <div className='system-details-meta-systemuser-name'>{systemUser.system.name}</div>
                                <div className='system-details-meta-systemuser-permissions'>
                                    <div className='system-details-meta-systemuser-permissions-scope'>{systemPermissions.filter((su: ISystemUser) => su.permission.name.toLowerCase() === 'systems.read').length === 1 && (<Icon iconName='CheckMark' />)}</div>
                                    <div className='system-details-meta-systemuser-permissions-scope'>{systemPermissions.filter((su: ISystemUser) => su.permission.name.toLowerCase() === 'systems.update').length === 1 && (<Icon iconName='CheckMark' />)}</div>
                                    <div className='system-details-meta-systemuser-permissions-scope'>{systemPermissions.filter((su: ISystemUser) => su.permission.name.toLowerCase() === 'systems.approve').length === 1 && (<Icon iconName='CheckMark' />)}</div>

                                    {/* (
                                    {systemPermissions.map((su: ISystemUser, index: number) => {
                                        return (<span>
                                            {convertToReadablePermission(su.permission.name)}
                                            {index + 1 < systemPermissions.length ? ', ' : ''}
                                        </span>)
                                    })}
                                    ) */}
                                </div>
                            </div>)

                            //strSystemPermissions = strSystemPermissions.substring(0, strSystemPermissions.length - 2);

                            //usersAndSystemPermissions += systemUser.user.firstName + ' ' + systemUser.user.lastName + ' (' + strSystemPermissions + ')' + '\n';
                        }
                    })}

                </>)



            //usersAndSystemPermissions = usersAndSystemPermissions.substring(0, usersAndSystemPermissions.length - 2);
        }

        //return usersAndSystemPermissions;
    }


    return (
        <div className='profile-wrapper'>
            <div style={{ marginBottom: '20px', fontSize: '16pt' }}>Brugerprofil</div>
            {props.currentUser !== null && props.currentUser !== undefined && (
                <>
                    <div className='profile-item'>
                        <div className='profile-label'>Bruger</div>
                        <div className='profile-value'><b>{props.currentUser.firstName} {props.currentUser.lastName}</b></div>

                    </div>
                    <div className='profile-item'>
                        <div className='profile-label'>Stabnr</div>
                        <div className='profile-value'>{props.currentUser.stabsnr}</div>
                    </div>
                    <div className='profile-item'>
                        <div className='profile-label'>Email</div>
                        <div className='profile-value'>{props.currentUser.email}</div>
                    </div>
                    <div className='profile-item'>
                        <div className='profile-label'>Myndighed</div>
                        <div className='profile-value'>{props.currentUser.organization.name}</div>
                    </div>
                    <div className='profile-item'>
                        <div className='profile-label'>Roller</div>
                        <div className='profile-value'>
                            {props.currentUser.userRoles.map((userRole: any) => {
                                return (<div key={userRole.id}>{userRole.role.name}</div>)
                            })}
                        </div>
                    </div>
                    <div className='profile-item'>
                        <div className='profile-label'>Rettigheder</div>
                        <div className='profile-value'>
                            {getPermissions(props.currentUser)}
                        </div>
                    </div>

                    {/* <div className='profile-item'>
                        <div className='profile-label'>Systemer</div>
                        <div className='profile-value'>
                            {getSystemPermissions(props.currentUser)}
                        </div>
                    </div> */}

                    <div className='profile-item'>
                        <div className='profile-label'>Systemer</div>
                        <div className='profile-value'>
                            {getSystemsAndUserPermissions(props.currentUser.systemUsers)}
                        </div>
                    </div>

                </>

            )}
        </div>
    )


}

export default Profile
