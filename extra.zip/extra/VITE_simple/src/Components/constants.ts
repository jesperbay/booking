


export const Constants = {
    System: {
        Status: {
            DRAFT: 'KLADDE',
            ACTIVE: 'AKTIV',
            CANCELLED: 'NEDLAGT',
            DELETED: 'SLETTET'
        }
    },
    Iteration: {
        Status: {
            ONGOING: 'IGANG',
            APPROVED: 'GODKENDT'
        }
    }
};