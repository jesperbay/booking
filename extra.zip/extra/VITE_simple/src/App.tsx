import { useEffect, useState } from 'react'

import { FluentProvider, webLightTheme, } from "@fluentui/react-components";
import './App.css'

import Systems from './Components/System/Systems'
import { Routes, Route, useLocation, useNavigate } from "react-router-dom"
import Menu from './Components/Menu/Menu'
import Header from './Components/Header/Header'
import Login from './Components/Login/Login'
import axios from 'axios';
import useAuth, { AuthProvider } from './Components/Providers/AuthProvider'
import Users from './Components/Users/Users'
import { initializeIcons } from '@fluentui/react';
import Profile from './Components/Profile/Profile';

initializeIcons();
axios.defaults.headers.common = { 'Authorization': `Bearer ${localStorage.getItem('lexi-token')}` }

const { Config } = (window as any)["Config"];

function App() {

  const InnerApp = (props: any) => {
    const { user, ...rest } = useAuth();
    const authProps = {
      currentUser: user,
      ...rest
    }


    let navigate = useNavigate();

    const interceptor = axios.interceptors.response.use(
      response => response,
      error => {
        if (error.response && error.response.status === 401) {
          // Clear user data and redirect to login
          //rest.logout();
          navigate("/login");
        }
        return Promise.reject(error);
      }
    );
    useEffect(() => {
      return () => {
        axios.interceptors.response.eject(interceptor);
      };
    }, [interceptor]);;

    return (
      <>
        <div className='app-wrapper'>
          <Header user={user}  {...authProps}></Header>
          <div className='main-wrapper'>
            <Menu user={user}></Menu>
            <div className='content-wrapper'>
              <FluentProvider theme={webLightTheme}>
                <Routes>
                  {user ? (
                    <>
                      <Route path="/" element={<Systems {...authProps} />} />
                      <Route path="/duties" element={<Systems {...authProps} />} />
                      <Route path="/users" element={<Users {...authProps} />} />
                      <Route path="/profile" element={<Profile {...authProps} />} />
                    </>
                  ) : (
                    <Route path="/login" element={<Login {...authProps} />} />
                  )}
                </Routes>
              </FluentProvider>
            </div>
          </div>
        </div >

      </>
    );

  }

  return (
    <AuthProvider>
      <InnerApp />
    </AuthProvider>
  )
}

export default App


