﻿using FSV.Lokalebooking.API.Models;

namespace FSV.Lokalebooking.API.Services
{
    public class RessourceService
    {
        public List<Ressource> Get()
        {
            using (BookingContext ctx = new BookingContext())
            {
                List<Ressource> ressources = ctx.Ressources.ToList();

                return ressources;
            }
        }

        public Ressource GetById(int id)
        {
            using (BookingContext ctx = new BookingContext())
            {
                Ressource ressource = ctx.Ressources.Where(r => r.Id == id).SingleOrDefault();

                return ressource;
            }
        }

        public Ressource Add(Ressource ressource)
        {
            using (BookingContext ctx = new BookingContext())
            {
                ctx.Ressources.Add(ressource);
                ctx.SaveChanges();

                return ressource;
            }
        }

        public Ressource Update(Ressource ressource)
        {
            using (BookingContext ctx = new BookingContext())
            {
                Ressource existingRessource = ctx.Ressources.Where(r => r.Id == ressource.Id).SingleOrDefault();
                if (existingRessource != null)
                {
                    existingRessource.Title = ressource.Title;
                    existingRessource.Description = ressource.Description;
                    existingRessource.LocationId = ressource.LocationId;
                    existingRessource.RessourceTypeId = ressource.RessourceTypeId;
                    ctx.SaveChanges();
                }


                return existingRessource;
            }
        }

        public bool Delete(int id)
        {
            using (BookingContext ctx = new BookingContext())
            {
                Ressource existingRessource = ctx.Ressources.Where(r => r.Id == id).SingleOrDefault();
                if (existingRessource != null)
                {
                    ctx.Ressources.Remove(existingRessource);
                    ctx.SaveChanges();
                }
            }
            return true;
        }
    }
}
