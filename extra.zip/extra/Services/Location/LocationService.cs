﻿using FSV.Lokalebooking.API.Models;

namespace FSV.Lokalebooking.API.Services
{
    public class LocationService
    {
        public List<Location> Get()
        {
            using (BookingContext ctx = new BookingContext())
            {
                List<Location> locations = ctx.Locations.ToList();

                return locations;
            }
        }

        public Location GetById(int id)
        {
            using (BookingContext ctx = new BookingContext())
            {
                Location location = ctx.Locations.Where(l => l.Id == id).SingleOrDefault();

                return location;
            }
        }

        public Location Add(Location location)
        {
            using (BookingContext ctx = new BookingContext())
            {
                ctx.Locations.Add(location);
                ctx.SaveChanges();

                return location;
            }
        }

        public Location Update(Location location)
        {
            using (BookingContext ctx = new BookingContext())
            {
                Location existingLocation = ctx.Locations.Where(l => l.Id == location.Id).SingleOrDefault();
                if(existingLocation != null)
                {
                    //existingLocation = location;
                    existingLocation.Title = location.Title;
                    existingLocation.Type = location.Type;
                    existingLocation.Description = location.Description;
                    existingLocation.ParentId = location.ParentId;
                    ctx.SaveChanges();
                }


                return existingLocation;
            }
        }

        public bool Delete(int id)
        {
            using (BookingContext ctx = new BookingContext())
            {
                Location existingLocation = ctx.Locations.Where(l => l.Id == id).SingleOrDefault();
                if (existingLocation != null)
                {
                    ctx.Locations.Remove(existingLocation);
                    ctx.SaveChanges();
                }
            }
            return true;
        }
    }
}
