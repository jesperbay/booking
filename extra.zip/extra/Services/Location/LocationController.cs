﻿using FSV.Lokalebooking.API.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FSV.Lokalebooking.API.Services
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {

        private readonly LocationService _locationService;

        public LocationController(LocationService locationService)
        {
            _locationService = locationService;
        }

        [HttpGet("get")]
        public List<Location> Get()
        {
            try
            {
                return _locationService.Get();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpGet("get/{id}")]
        public Location GetById(int id)
        {
            try
            {
                return _locationService.GetById(id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        [HttpPost("save")]
        public Location Add([FromBody] Location location)
        {
            try
            {
                return _locationService.Add(location);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPut("update")]
        public Location Update([FromBody]Location location)
        {
            try
            {
                return _locationService.Update(location);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpDelete("delete/{id}")]
        public bool delete(int id)
        {
            try
            {
                return _locationService.Delete(id);
            }
            catch (Exception ex)
            {
                return false;
            }
        }


    }
}
