﻿using FSV.Lokalebooking.API.Models;

namespace FSV.Lokalebooking.API.Services
{
    public class ReservationService
    {
        public List<Reservation> Get()
        {
            using (BookingContext ctx = new BookingContext())
            {
                List<Reservation> reservations = ctx.Reservations.ToList();

                return reservations;
            }
        }

        public Reservation GetById(int id)
        {
            using (BookingContext ctx = new BookingContext())
            {
                Reservation reservation = ctx.Reservations.Where(r => r.Id == id).SingleOrDefault();

                return reservation;
            }
        }

        public Reservation Add(Reservation reservation)
        {
            using (BookingContext ctx = new BookingContext())
            {
                ctx.Reservations.Add(reservation);
                ctx.SaveChanges();

                return reservation;
            }
        }

        public Reservation Update(Reservation reservation)
        {
            using (BookingContext ctx = new BookingContext())
            {
                Reservation existingReservation= ctx.Reservations.Where(r => r.Id == reservation.Id).SingleOrDefault();
                if (existingReservation != null)
                {
                    existingReservation.Start = reservation.Start;
                    existingReservation.End = reservation.End;
                    existingReservation.Note = reservation.Note;
                    existingReservation.PropertiesJSON = reservation.PropertiesJSON;
                    existingReservation.RessourceId = reservation.RessourceId;
                    existingReservation.ReservedToId = reservation.ReservedToId;
                    ctx.SaveChanges();
                }


                return existingReservation;
            }
        }

        public bool Delete(int id)
        {
            using (BookingContext ctx = new BookingContext())
            {
                Reservation existingReservation = ctx.Reservations.Where(l => l.Id == id).SingleOrDefault();
                if (existingReservation != null)
                {
                    ctx.Reservations.Remove(existingReservation);
                    ctx.SaveChanges();
                }
            }
            return true;
        }

    }
}
