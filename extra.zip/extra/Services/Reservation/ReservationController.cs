﻿using FSV.Lokalebooking.API.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FSV.Lokalebooking.API.Services
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {

        private readonly ReservationService _reservationService;

        public ReservationController(ReservationService reservationService)
        {
            _reservationService = reservationService;
        }

        [HttpGet("Get")]
        public List<Reservation> Get()
        {
            try
            {
                return _reservationService.Get();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpGet("get/{id}")]
        public Reservation GetById(int id)
        {
            try
            {
                return _reservationService.GetById(id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        [HttpPost("save")]
        public Reservation Add([FromBody] Reservation reservation)
        {
            try
            {
                return _reservationService.Add(reservation);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPut("update")]
        public Reservation Update([FromBody] Reservation reservation)
        {
            try
            {
                return _reservationService.Update(reservation);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpDelete("delete/{id}")]
        public bool delete(int id)
        {
            try
            {
                return _reservationService.Delete(id);
            }
            catch (Exception ex)
            {
                return false;
            }
        }


    }
}
