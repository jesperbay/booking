﻿using FSV.Lokalebooking.API.Models;

namespace FSV.Lokalebooking.API.Services
{
    public class UserService
    {
        public List<User> GetUsers()
        {
            using (BookingContext ctx = new BookingContext())
            {
                List<User> users = ctx.Users.ToList();

                return users;
            }
        }
    }
}
