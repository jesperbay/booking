import './App.css'
import Header from './components/Header/Header'
import Menu from './components/Menu/Menu'

function App() {

  return (
    <div className="layout-wrapper">
      <Header />
      <div className="content-wrapper">
        <Menu />
        <div className='content'>Route</div>
      </div>
    </div>
  )
}

export default App
