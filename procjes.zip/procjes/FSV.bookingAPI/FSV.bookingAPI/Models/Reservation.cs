﻿namespace FSV.bookingAPI.Models
{
    public class Reservation
    {
        public int Id { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public string? Note { get; set; }
        public string Status { get; set; }
        public int RessouredId { get; set; }
        public int ReservedToId { get; set; }
        public DateTime Approved { get; set; }
        public int ApprovedById { get; set; }
        public int ApprovedId { get; set; }
        public DateTime Created { get; set; }
        public int CreatedById { get; set; }
        public DateTime Modified { get; set; }
        public int ModifiedById { get; set; }
        public string? PropertiesJson { get; set; }

        public virtual Ressource? Ressource { get; set; }
        public virtual User? ReservedTo { get; set; }
        public virtual User? ApprovedBy { get; set; }
        public virtual User? ModifiedBy { get; set; }
        public virtual User? CreatedBy { get; set; }

    }
}
