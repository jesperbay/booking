﻿namespace FSV.bookingAPI.Models
{
    public class LoginRequst
    {
        public string UserName { get; set; }
        public string Password { get; set; }    
    }
}
