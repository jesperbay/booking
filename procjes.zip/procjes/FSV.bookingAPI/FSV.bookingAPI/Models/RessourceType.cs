﻿namespace FSV.bookingAPI.Models
{
    public class RessourceType
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
