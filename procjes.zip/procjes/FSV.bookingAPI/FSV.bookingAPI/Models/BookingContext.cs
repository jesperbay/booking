﻿using Microsoft.EntityFrameworkCore;

namespace FSV.bookingAPI.Models
{
    public class BookingContext: DbContext
    {
        public DbSet<Location> Locations { get; set; }
        public DbSet<Reservation> Reservations { get; set; }
        public DbSet<Ressource> Ressources { get; set; }
        public DbSet<RessourceType> ressourceTypes { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
              .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
              .AddJsonFile("appsettings.json")
              .AddEnvironmentVariables()
              .Build();
           
            optionsBuilder.UseSqlServer(configuration["Booking_DB"]);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Reservation>().HasOne(r => r.ApprovedBy).WithMany().OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Reservation>().HasOne(r => r.ReservedTo).WithMany().OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Reservation>().HasOne(r => r.CreatedBy).WithMany().OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Reservation>().HasOne(r => r.ModifiedBy).WithMany().OnDelete(DeleteBehavior.Restrict);


            modelBuilder.Entity<RessourceType>().HasData(
                new RessourceType { Id = 1, Title = "Skrivebord" },
                new RessourceType { Id = 2, Title = "Lokale" }
            );


            modelBuilder.Entity<Location>().HasData(
                new Location { Id = 1, Title = "Hvidovre", Type = "By", Description = "", ParentId = null },
                new Location { Id = 2, Title = "Cyberdivisionen", Type = "Etab", Description = "", ParentId = 1 },
                new Location { Id = 3, Title = "Bygning A", Type = "Bygning", Description = "", ParentId = 2 },
                new Location { Id = 4, Title = "Lokale A0.207", Type = "Lokale", Description = "", ParentId = 3 },
                new Location { Id = 5, Title = "Bygning B", Type = "Bygning", Description = "", ParentId = 2 },
                new Location { Id = 6, Title = "Lokale B0.211", Type = "Bygning", Description = "", ParentId = 5 }
            );

            modelBuilder.Entity<Role>().HasData(
                new Role { Id = 1, Name = "Admin" },
                new Role { Id = 2, Name = "User" }
            );

            modelBuilder.Entity<User>().HasData(
                new User { Id = 1, FirstName = "Super", LastName = "Mand", Email = "super@mand.dk", MAno = "111111", Password = "Pw1", RoleId = 1, UserName = "super" },
                new User { Id = 2, FirstName = "Anders", LastName = "And", Email = "anders@and.dk", MAno = "222222", Password = "Pw1", RoleId = 2, UserName = "anders" }
            );

            modelBuilder.Entity<Ressource>().HasData(
                new Ressource { Id = 1, Title = "Skrivebord 1 (A0.207)", Description = "2x24\" med USB-C Dock, Keyboard/mus", Enabled = true, LocationId = 4, RessourceTypeId = 1 },
                new Ressource { Id = 2, Title = "Skrivebord 2 (A0.207)", Description = "2x27\" med USB-C Dock, Keyboard/mus", Enabled = true, LocationId = 4, RessourceTypeId = 1 },
                new Ressource { Id = 3, Title = "Lokale A0.207", Description = "Lokale med 2 arb pladser", Enabled = true, LocationId = 4, RessourceTypeId = 2 },
                new Ressource { Id = 4, Title = "Skrivebord 3 (B0.211)", Description = "2x24\" med USB-C Dock, Keyboard/mus", Enabled = true, LocationId = 6, RessourceTypeId = 1 },
                new Ressource { Id = 5, Title = "Skrivebord 4 (B0.211)", Description = "2x27\" med USB-C Dock, Keyboard/mus", Enabled = true, LocationId = 6, RessourceTypeId = 1 },
                new Ressource { Id = 6, Title = "Lokale B0.211", Description = "Lokale med 2 arb pladser", Enabled = true, LocationId = 6, RessourceTypeId = 2 }
            );
        }
    }
}
