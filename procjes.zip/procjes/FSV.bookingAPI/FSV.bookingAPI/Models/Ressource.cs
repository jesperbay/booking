﻿namespace FSV.bookingAPI.Models
{
    public class Ressource
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string? Description { get; set; }
        public bool Enabled { get; set; }
        public int RessourceTypeId { get; set; }
        public int LocationId { get; set; }
        public virtual RessourceType? RessourceType { get; set; }
        public virtual Location? Location { get; set; }
    }
}
