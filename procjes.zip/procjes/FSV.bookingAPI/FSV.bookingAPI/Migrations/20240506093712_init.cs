﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace FSV.bookingAPI.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Locations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Type = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ParentId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Locations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ressourceTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ressourceTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Roles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Roles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Ressources",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Enabled = table.Column<bool>(type: "bit", nullable: false),
                    RessourceTypeId = table.Column<int>(type: "int", nullable: false),
                    LocationId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ressources", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Ressources_Locations_LocationId",
                        column: x => x.LocationId,
                        principalTable: "Locations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Ressources_ressourceTypes_RessourceTypeId",
                        column: x => x.RessourceTypeId,
                        principalTable: "ressourceTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MAno = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastLogin = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RoleId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Users_Roles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "Roles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Reservations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Start = table.Column<DateTime>(type: "datetime2", nullable: false),
                    End = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Note = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RessouredId = table.Column<int>(type: "int", nullable: false),
                    ReservedToId = table.Column<int>(type: "int", nullable: false),
                    Approved = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ApprovedById = table.Column<int>(type: "int", nullable: false),
                    ApprovedId = table.Column<int>(type: "int", nullable: false),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedById = table.Column<int>(type: "int", nullable: false),
                    Modified = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedById = table.Column<int>(type: "int", nullable: false),
                    PropertiesJson = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RessourceId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reservations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Reservations_Ressources_RessourceId",
                        column: x => x.RessourceId,
                        principalTable: "Ressources",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Reservations_Users_ApprovedById",
                        column: x => x.ApprovedById,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Reservations_Users_CreatedById",
                        column: x => x.CreatedById,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Reservations_Users_ModifiedById",
                        column: x => x.ModifiedById,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Reservations_Users_ReservedToId",
                        column: x => x.ReservedToId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Locations",
                columns: new[] { "Id", "Description", "ParentId", "Title", "Type" },
                values: new object[,]
                {
                    { 1, "", null, "Hvidovre", "By" },
                    { 2, "", 1, "Cyberdivisionen", "Etab" },
                    { 3, "", 2, "Bygning A", "Bygning" },
                    { 4, "", 3, "Lokale A0.207", "Lokale" },
                    { 5, "", 2, "Bygning B", "Bygning" },
                    { 6, "", 5, "Lokale B0.211", "Bygning" }
                });

            migrationBuilder.InsertData(
                table: "Roles",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Admin" },
                    { 2, "User" }
                });

            migrationBuilder.InsertData(
                table: "ressourceTypes",
                columns: new[] { "Id", "Title" },
                values: new object[,]
                {
                    { 1, "Skrivebord" },
                    { 2, "Lokale" }
                });

            migrationBuilder.InsertData(
                table: "Ressources",
                columns: new[] { "Id", "Description", "Enabled", "LocationId", "RessourceTypeId", "Title" },
                values: new object[,]
                {
                    { 1, "2x24\" med USB-C Dock, Keyboard/mus", true, 4, 1, "Skrivebord 1 (A0.207)" },
                    { 2, "2x27\" med USB-C Dock, Keyboard/mus", true, 4, 1, "Skrivebord 2 (A0.207)" },
                    { 3, "Lokale med 2 arb pladser", true, 4, 2, "Lokale A0.207" },
                    { 4, "2x24\" med USB-C Dock, Keyboard/mus", true, 6, 1, "Skrivebord 3 (B0.211)" },
                    { 5, "2x27\" med USB-C Dock, Keyboard/mus", true, 6, 1, "Skrivebord 4 (B0.211)" },
                    { 6, "Lokale med 2 arb pladser", true, 6, 2, "Lokale B0.211" }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Email", "FirstName", "LastLogin", "LastName", "MAno", "Password", "RoleId", "UserName" },
                values: new object[,]
                {
                    { 1, "super@mand.dk", "Super", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Mand", "111111", "Pw1", 1, "super" },
                    { 2, "anders@and.dk", "Anders", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "And", "222222", "Pw1", 2, "anders" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_ApprovedById",
                table: "Reservations",
                column: "ApprovedById");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_CreatedById",
                table: "Reservations",
                column: "CreatedById");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_ModifiedById",
                table: "Reservations",
                column: "ModifiedById");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_ReservedToId",
                table: "Reservations",
                column: "ReservedToId");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_RessourceId",
                table: "Reservations",
                column: "RessourceId");

            migrationBuilder.CreateIndex(
                name: "IX_Ressources_LocationId",
                table: "Ressources",
                column: "LocationId");

            migrationBuilder.CreateIndex(
                name: "IX_Ressources_RessourceTypeId",
                table: "Ressources",
                column: "RessourceTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Users_RoleId",
                table: "Users",
                column: "RoleId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Reservations");

            migrationBuilder.DropTable(
                name: "Ressources");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Locations");

            migrationBuilder.DropTable(
                name: "ressourceTypes");

            migrationBuilder.DropTable(
                name: "Roles");
        }
    }
}
