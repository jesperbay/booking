﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FSV.bookingAPI.Services
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
    }
}
