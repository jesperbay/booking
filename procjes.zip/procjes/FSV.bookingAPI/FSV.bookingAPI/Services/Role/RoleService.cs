﻿namespace FSV.bookingAPI.Services.Role
{
    public class RoleService
    {
    }
}
