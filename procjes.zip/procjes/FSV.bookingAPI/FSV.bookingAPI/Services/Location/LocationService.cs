﻿using FSV.bookingAPI.Models;

namespace FSV.bookingAPI.Services
{
    public class LocationService
    {
        public List<Location> GetLocations()
        {
            using(BookingContext bookingContext = new BookingContext())
                return bookingContext.Locations.ToList();
        }

        public Location GetLocationById(int id) 
        {
            using(BookingContext bookingContext = new BookingContext())
            {
                return bookingContext.Locations.FirstOrDefault(l => l.Id == id);
            }
        }

        public Location AddLocation(Location location) 
        {
            using (BookingContext bookingContext = new BookingContext())
            {
               bookingContext.Locations.Add(location);
            }
            return location;
        }

        public Location UpadeLocation(Location location)
        {
            using (BookingContext bookingContext = new BookingContext())
            {
                Location currentLocation = bookingContext.Locations.FirstOrDefault(l => l.Id == location.Id);
                if (currentLocation != null) 
                {
                    currentLocation.Title = location.Title;
                    bookingContext.Locations.Update(currentLocation);
                    return location;
                }
            }
            return null;
        }

        public bool DeleteLocation(int id)
        {
            using (BookingContext bookingContext = new BookingContext())
            {
                Location currentLocation = bookingContext.Locations.FirstOrDefault(l => l.Id == id);
                if(currentLocation != null)
                {
                    bookingContext.Locations.Remove(currentLocation);
                    return true;
                }
            }
            return false;
        }
    }
}
