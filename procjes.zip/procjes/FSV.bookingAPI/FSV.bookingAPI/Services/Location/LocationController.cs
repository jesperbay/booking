﻿using FSV.bookingAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FSV.bookingAPI.Services
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        public LocationService _LocationService { get; set; }
        
        public LocationController(LocationService locationService) 
        { 
            _LocationService = locationService;
        }

        [HttpGet("")]
        public List<Location> GetLocation()
        {
            return _LocationService.GetLocations();
        }

        [HttpGet("(id)")]
        public Location GetLocationById(int id)
        {
            return _LocationService.GetLocationById(id);
        }

        [HttpPost("")]
        public Location Add(Location location)
        {
            return _LocationService.AddLocation(location);
        }
        [HttpDelete("(id)")]
        public bool Delete(int id)
        {
            return _LocationService.DeleteLocation(id);
        }
    }
}
