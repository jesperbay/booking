﻿using FSV.bookingAPI.Models;
using FSV.bookingAPI;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using FSV.bookingAPI.Services;
using Microsoft.Extensions.Logging;

namespace FSV.Lokalebooking.API.Services
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {

        private readonly UserService _userService;
        private readonly ILogger<UserController> _logger;

    

        public UserController(UserService userService)
        {
            _userService = userService;

        }

        [HttpGet("Get")]
        public List<User> Get()
        {
            try
            {
                return _userService.GetUsers();
            }
            catch (Exception ex)
            {
                return null;
            }
        }


    }
}
