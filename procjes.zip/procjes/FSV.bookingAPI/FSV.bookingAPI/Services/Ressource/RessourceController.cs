﻿using FSV.bookingAPI.Models;
using FSV.bookingAPI.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.Design;

namespace FSV.Lokalebooking.API.Services
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class RessourceController : ControllerBase
    {
        private readonly RessourceService _ressourceService;

        public RessourceController(RessourceService ressourceService)
        {
            _ressourceService = ressourceService;
        }

        [HttpGet("get")]
        public List<Ressource> Get()
        {
            try
            {
                return _ressourceService.Get();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpGet("get/{id}")]
        public Ressource GetById(int id)
        {
            try
            {
                return _ressourceService.GetById(id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        [HttpPost("save")]
        public Ressource Add([FromBody] Ressource ressource)
        {
            try
            {
                return _ressourceService.Add(ressource);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPut("update")]
        public Ressource Update([FromBody] Ressource ressource)
        {
            try
            {
                return _ressourceService.Update(ressource);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpDelete("delete/{id}")]
        public bool delete(int id)
        {
            try
            {
                return _ressourceService.Delete(id);
            }
            catch (Exception ex)
            {
                return false;
            }
        }


    }
}
