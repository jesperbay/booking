﻿using FSV.bookingAPI.Models;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace FSV.bookingAPI.Services.Authentication
{
    public class AuthenticationService
    {
        private IConfiguration _config;
   
        public AuthenticationService(IConfiguration config)
        {
            _config = config;
        }
        public string Login(LoginRequst LoginRequest)
        {

            using (var content = new BookingContext())
            {
                var currentUser = content.Users.Include(u => u.Role).FirstOrDefault(u => u.UserName == LoginRequest.UserName && u.Password == LoginRequest.Password);



                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

                var Sectoken = new JwtSecurityToken(_config["Jwt:Issuer"],
                  _config["Jwt:Issuer"],
                  claims: new List<Claim>
                  {
                  new Claim(ClaimTypes.Role, currentUser.Role.Name),
                  new Claim("MAno", currentUser.MAno),
                  new Claim(ClaimTypes.Name, currentUser.UserName),
                  },
    
                  expires: DateTime.Now.AddMinutes(120),
                  signingCredentials: credentials);

                var token = new JwtSecurityTokenHandler().WriteToken(Sectoken);

                return token;
            }
        }

        public User ValidateToken(string token, IConfiguration _config)
        {
            using (BookingContext ctx = new BookingContext())
            {
                //your logic for login process
                //If login usrename and password are correct then proceed to generate token

                JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();

                var securityToken = tokenHandler.ReadToken(token) as JwtSecurityToken;

                string UserManoFromToken = securityToken.Claims.First(Claim => Claim.Type == ClaimTypes.Name).Value;

                User existingUser = ctx.Users.Where(u => u.UserName == UserManoFromToken).Include(u => u.Role).SingleOrDefault();
                return existingUser;
            }
        }
    }
}
