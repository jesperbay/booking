﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using FSV.bookingAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Net.Http.Headers;

namespace FSV.bookingAPI.Services.Authentication
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {


        private IConfiguration _config;
        private AuthenticationService _AuthenticationService;

        public AuthenticationController(IConfiguration config, AuthenticationService authenticationService)
        {
            _config = config;
            _AuthenticationService = authenticationService;
        }



        [HttpPost("Login")]
        public IActionResult login([FromBody] LoginRequst loginRequest)
        {
            string token = _AuthenticationService.Login(loginRequest);

            if(token != "")
            {
                return Ok(token);
            }
            else
            {
                return BadRequest();
            }
            
        }

        [HttpGet]
        [Authorize]
        public IActionResult ValidateToken()
        {
            try
            {
                string token = Request.Headers[HeaderNames.Authorization].ToString().Replace("Bearer ", "");
                User user = _AuthenticationService.ValidateToken(token, _config);

                if (token.Length > 0)
                {
                    return Ok(user);
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

    }
}
