import { Navigate, Route, Routes, useNavigate } from 'react-router-dom'
import './App.css'
import { ThemeProvider, PartialTheme } from '@fluentui/react';
import Header from './Component/Header/Header'
import Menu from './Component/Menu/Menu'
import Home from "./views/Home/Home"
import Login from "./views/Login/login"
import Reservations from "./views/Reservations/Reservations"
import { useEffect, useState } from 'react'
import Authservice from './Service/AuthService';
import { IUser } from '../Interface'
import Ressources from './views/Ressources/Ressources'
import Locations from './views/Location/Locations'
import { Icon } from '@fluentui/react/lib/Icon';
import { initializeIcons } from '@fluentui/font-icons-mdl2';

initializeIcons();

function App() {
  

const [user, setuser] = useState<IUser | null>(null);
const navigate = useNavigate();

useEffect(()=>{
  const token = localStorage.getItem('booking-token');
  if(!token){
    navigate("/login");
  }else{
    Authservice.ValidateToken(token, (user: IUser| null) =>{
      if(user){
        setuser(user);
        navigate("/");
      }
      
    })
  }}, [])

const handleLogin = (userName: string, Password: string) =>{
  console.log(userName, Password);
  Authservice.HandleLogin(userName, Password, (token: string)=>{
    
    localStorage.setItem("booking-token", token);
    Authservice.ValidateToken(token, (user: IUser| null) =>{
      if(user){
        setuser(user);
        navigate("/");
      }
      
    })
  })
}

  return (
    <div className="layout-wrapper">
      <Header />
      <div className="content-wrapper">
        <Menu />
        <div className='content'>
          <Routes>
            <>
            {user ? (
              <><Route path="/" element={<Home />} /><Route path="/Login" element={<Login login={handleLogin} />} /><Route path="/Reservations" element={<Reservations />} /><Route path="/Ressources" element={<Ressources />} /><Route path="/Locations" element={<Locations />} /></>
            ) : (
              <Route path="/login" element={<Login login={handleLogin}/>} />
            )}
            </>
          </Routes>
        </div>
      </div>
    </div>
  )
}

export default App
