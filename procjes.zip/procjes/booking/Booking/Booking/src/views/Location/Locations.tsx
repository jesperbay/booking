import { useEffect, useState } from 'react'
import './Locations.css'
import { DetailsList, DetailsListLayoutMode, IColumn, SelectionMode } from '@fluentui/react'
import { ILocation, IRessource } from '../../../Interface';
import LocationService from '../../Service/LocationService';

function Locations() {
  const [ items, setItems ] = useState<ILocation[]>([]);
  const [ columns, setColumns ] = useState<IColumn[]>([]);

  useEffect(() => {
    if(columns.length === 0){
      loadColumns();  
    }
    
    if(items.length === 0){
      loadItems();  
    }
  },[])

  const loadColumns = () => {
    setColumns([
      {
        key: 'column1',
        name: 'Id',
        fieldName: 'Id',
        minWidth: 40,
        maxWidth: 40,
        onRender: (Location: ILocation) => (
          <span>{Location.id}</span>
        ),
      },
      {
        key: 'column2',
        name: 'Name',
        fieldName: 'name',
        minWidth: 200,
        maxWidth: 200,
        onRender: (Location: ILocation) => (
          <span>{Location.title}</span>
        ),
      },
      {
        key: 'column3',
        name: 'City',
        fieldName: 'name',
        minWidth: 120,
        maxWidth: 120,
        onRender: (Location: ILocation) => (
          <span>{Location.type}</span>
        ),
      }
    ]);
    

  }

  const loadItems = () => {

    LocationService.GetLocations((Location: ILocation[]) => {
      setItems(Location);
    })
  }

  return (
    <div>
     Location 
     <div>

     <DetailsList
              items={items}
              columns={columns}
              selectionMode={SelectionMode.multiple}
              setKey="multiple"
              layoutMode={DetailsListLayoutMode.justified}
              isHeaderVisible={true}
              // selection={this._selection}
              selectionPreservedOnEmptyClick={true}
              enterModalSelectionOnTouch={true}
            />
     </div>
    </div>
  )
}

export default Locations
