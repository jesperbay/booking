
function reservations(){
    return (
        <div className="">
        <p>Reservations</p>
        </div>
    )
}

export default reservations;