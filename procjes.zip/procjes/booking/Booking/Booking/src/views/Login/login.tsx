import { PrimaryButton, TextField } from "@fluentui/react";
import { useState } from "react";

interface IloginProps{
    login: (userName: string, passeword: string) => void;
}





function login(props: IloginProps){

const [userName, setUserName] = useState<string>("")
const [passeword, setPassword] = useState<string>("")

const onChangeUserName = (event: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string | undefined): void =>{
setUserName(newValue ?? "")
}

const onChangePassword = (event: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string | undefined): void =>{
setPassword(newValue ?? "")
}


    return (
        <div className="">
        <p>login</p>
        <TextField label="Brugnavn" value={userName}  onChange={(onChangeUserName)}  />
        <TextField label="Kodeord" value={passeword} type="password" onChange={(onChangePassword)}/>
        <PrimaryButton text="Login" style={{margin: 10}} onClick={() =>{props.login(userName, passeword)}} />
        </div>
    )
}

export default login;