

function home(){
    return (
        <div className="">
        <p>Home</p>
        </div>
    )
}

export default home;