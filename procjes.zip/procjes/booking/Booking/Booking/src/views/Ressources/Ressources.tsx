import { useEffect, useState } from 'react'
import './Ressources.css'
import { DetailsList, DetailsListLayoutMode, IColumn, IconButton, SelectionMode } from '@fluentui/react'
import { IRessource } from '../../../Interface';
import RessourceService from '../../Service/RessourceService';
import { Icon } from '@fluentui/react/lib/Icon';

function Ressources() {
  const [ items, setItems ] = useState<IRessource[]>([]);
  const [ columns, setColumns ] = useState<IColumn[]>([]);
  const [selectionItem, setSelectionItem] = useState<IRessource | null>(null);


  useEffect(() => {
    if(columns.length === 0){
      loadColumns();  
    }
    
    if(items.length === 0){
      loadItems();  
    }
  },[])

  const loadColumns = () => {
    setColumns([
      {
        key: 'column1',
        name: 'Id',
        fieldName: 'Id',
        minWidth: 40,
        maxWidth: 40,
        onRender: (ressource: IRessource) => (
          <span>{ressource.id}</span>
        ),
      },
      {
        key: 'column2',
        name: 'Name',
        fieldName: 'name',
        minWidth: 200,
        maxWidth: 200,
        onRender: (ressource: IRessource) => (
          <>
          <span>{ressource.title}</span>
          
          </>
        ),
      },
      {
        key: 'column3',
        name: 'Type',
        fieldName: 'name',
        minWidth: 120,
        maxWidth: 120,
        onRender: (ressource: IRessource) => (
          <span>{ressource.ressourceTypeId}</span>
        ),
      },
      {
        key: 'column4',
        name: 'Type',
        fieldName: 'name',
        minWidth: 120,
        maxWidth: 120,
        onRender: (ressource: IRessource) => (
          <>
          <IconButton iconProps={{ iconName: 'edit' }} title="edit" ariaLabel="edit" />
          <IconButton iconProps={{ iconName: 'delete' }} title="delete" ariaLabel="delete" onClick={()=> {
             console.log('');
          }}/>
          </>
          
        ),
      }
    ]);
    

  }


  

  const loadItems = () => {

    RessourceService.GetRessources((ressources:IRessource[]) => {
      setItems(ressources);
    })
  }

  return (
    <div>
     Ressourcer 
     <div>

     <DetailsList
              items={items}
              columns={columns}
              selectionMode={SelectionMode.multiple}
              setKey="set"
              layoutMode={DetailsListLayoutMode.justified}
              isHeaderVisible={true}
              selectionPreservedOnEmptyClick={true}
              enterModalSelectionOnTouch={true}
            />
     </div>
    </div>
  )
}

export default Ressources
