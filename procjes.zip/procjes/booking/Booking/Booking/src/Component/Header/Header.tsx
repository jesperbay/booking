import "./Header.css"

function Header(){
    return (
        <div className="header">
        <p>header</p>
        </div>
    )
}

export default Header;