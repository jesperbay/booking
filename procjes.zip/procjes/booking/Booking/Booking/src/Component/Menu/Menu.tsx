import "./Menu.css";
import "../../../Interface";
import { IUser } from "../../../Interface";
import { Link } from "react-router-dom";
import { PrimaryButton } from "@fluentui/react";

interface IMenuProps{
    user: IUser | null;
    logout: ()=> void;
}

const logout = null;

function Menu(){
    return (
        <div className="navigation">
           

            
            <div style={{display: "flex", flexDirection: "column", justifyContent: "space-between", height:'calc(100vh-100px)'}}>
               <div style={{display: "flex", flexDirection: "column"}}>
                    <Link to="/">Home</Link>
                    <Link to="/Reservations">Reservations</Link>
                    <Link to="/Ressources">Ressources</Link>
                    <Link to="/Locations">Locations</Link>
               </div>
               <div style={{display: "flex", bottom:"0"}}>
                 <PrimaryButton>log out</PrimaryButton>
               </div>
               
            </div>
        </div>
  
    )
}

export default Menu;