import { IUser } from "../../Interface"
import axios from 'axios';

/* const { Config } = (window as any)["Config"]; */

var API_URL_PREFIX =  'https://localhost:44304/api/';

class AuthService {

    public HandleLogin = (userName: string, password: string, callback: any) => {
        var loginUrl: string = API_URL_PREFIX + `Authentication/Login`;
        axios.post<IUser[]>(loginUrl,
            {
                "userName": userName,
                "password": password
            })
            .then((response) => {
                var token = response.data;
                // console.log(token);
                callback(token);
            });
    }

    public ValidateToken = (token: string, callback: (user: IUser | null) => void) => {
        const loginUrl: string = API_URL_PREFIX + `authentication`;
        axios.get<IUser>(loginUrl,  { headers: { Authorization: `Bearer ${token}` } })
            .then((response) => {
                const user: IUser = response.data;
                callback(user);
            })
            .catch((error) => {
                console.error("Error validating token:", error);
                callback(null);
            });
    }

    public HandleSSOLogin = (callback: any) => {

        const _configHeaders: any = {
            method: 'GET',
            credentials: 'include',
        };

       /*  var SSOUrl: string = Config.AuthUrl;


        fetch(SSOUrl, _configHeaders).then((response) => {
            response.json().then(function (data) {
                var ssoData = data;
                // console.log(token);
                callback(ssoData);
            })
        }).catch((error) => {
            console.log(error);
        });
 */


        // axios.get<any>(SSOUrl, _configHeaders)
        //     .then((response) => {
        //         var ssoData = response.data;
        //         // console.log(token);
        //         callback(ssoData);
        //     });
    }

    public HandleValidateSSOLogin = (user: any, callback: any) => {

        const url: string = API_URL_PREFIX + `authentication/validatessocode`;
        axios.post<any>(url, user)
            .then((response) => {
                var token = response.data;
                console.log(token);
                callback(token);
            });
    }

}

const singleton = new AuthService();
export default singleton;