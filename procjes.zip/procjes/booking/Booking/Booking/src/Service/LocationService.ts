import axios from 'axios';
import { ILocation, IRessource, IUser } from '../../Interface';

var API_URL_PREFIX = 'https://localhost:44304/';

class LocationService {

    public GetLocations = (callback: any) => {

        

const token = localStorage.getItem("booking-token")
        // // Get from API
        var url: string = API_URL_PREFIX + `api/Location`;
         axios.get<ILocation>(url, { headers: { Authorization: `Bearer ${token}` } })
             .then((response) => {
                 callback(response.data);
            });
    }
}

const singleton = new LocationService();
export default singleton;