import axios from 'axios';
import { IRessource, IUser } from '../../Interface';

var API_URL_PREFIX = 'https://localhost:44304/';

class RessourceService {

    public GetRessources = (callback: any) => {

        

const token = localStorage.getItem("booking-token")
        // // Get from API
        var url: string = API_URL_PREFIX + `api/ressource/get`;
         axios.get<IRessource>(url, { headers: { Authorization: `Bearer ${token}` } })
             .then((response) => {
                 callback(response.data);
            });
    }
}


/**
 * addRessource
 */

function addRessource() {
  var url: string = API_URL_PREFIX + `api/ressource/get`;
  const token = localStorage.getItem("booking-token")
  axios.post<IRessource>(url, { headers: { Authorization: `Bearer ${token}` } }, {
    
  })
  .then(res => {
    console.log(res);
    console.log(res.data);
  })
}
  


const singleton = new RessourceService();
export default singleton;