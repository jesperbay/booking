export interface IUser {
    id: Number
    firstName : String
    larstName: String
    userName: String
    passeword: String
    email: String
    maNo: String
    lastLogin: Date
    roleId: Number
    }
    
 export interface IRole{
      id: number
      name: string
    }

export interface IReservation {
  id: number;
  start: Date;
  end: Date;
  note?: string;
  status: string;
  ressouredId: number;
  reservedToId: number;
  approved: Date;
  approvedById: number;
  approvedId: number;
  created: Date;
  createdById: number;
  modified: Date;
  modifiedById: number;
  propertiesJson?: string;

  ressource?: IRessource;
  reservedTo?: IUser;
  approvedBy?: IUser;
  modifiedBy?: IUser;
  createdBy?: IUser;
}


export interface ILocation {
  id: number;
  title: string;
  description?: string;
  type: string;
  parentId?: number;
}


export interface IRessource {
  id: number;
  title: string;
  description?: string;
  enabled: boolean;
  ressourceTypeId: number;
  locationId: number;
  ressourceType?: IRessourceType;
  location?: ILocation;
}

// Define related interfaces (RessourceType and Location) if needed
export interface IRessourceType {
 id: number;
 title: string;
}



